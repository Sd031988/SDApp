@echo off
rem Startet den Ollama-Launcher unsichtbar im Hintergrund (ohne Konsolenfenster).
rem Mit Konsolenfenster (zur Fehlersuche):  Ollama_Start.bat konsole
cd /d "%~dp0"

set "PYW="
set "PY="
where pyw >nul 2>nul && (set "PYW=pyw -3")
where py  >nul 2>nul && (set "PY=py -3")
if not defined PYW (if exist "C:\Program Files\Python314\pythonw.exe" set "PYW="C:\Program Files\Python314\pythonw.exe"")
if not defined PY  (if exist "C:\Program Files\Python314\python.exe"  set "PY="C:\Program Files\Python314\python.exe"")
if not defined PYW (if exist "%LOCALAPPDATA%\Programs\Python\Python314\pythonw.exe" set "PYW="%LOCALAPPDATA%\Programs\Python\Python314\pythonw.exe"")
if not defined PY  (if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"  set "PY="%LOCALAPPDATA%\Programs\Python\Python314\python.exe"")
if not defined PYW (where pythonw >nul 2>nul && (set "PYW=pythonw"))
if not defined PY  (where python  >nul 2>nul && (set "PY=python"))

if /i "%~1"=="konsole" goto konsole
if not defined PYW goto konsole

start "" %PYW% "%~dp0Ollama_Start.py"
exit /b 0

:konsole
chcp 65001 >nul
title Sulaiman Durrani Open Source KI-Agent
if not defined PY (
  echo [!] Python wurde nicht gefunden.
  echo Gesucht: py-Launcher, C:\Program Files\Python314 und python im PATH.
  pause
  exit /b 1
)
%PY% "%~dp0Ollama_Start.py"
