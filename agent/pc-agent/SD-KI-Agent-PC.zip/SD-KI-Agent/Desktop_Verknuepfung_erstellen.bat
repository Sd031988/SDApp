@echo off
rem Legt auf dem Desktop eine Verknüpfung "Sulaiman Durrani KI-Agent" an, die Ollama_Start.bat startet.
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0Ollama_Start.bat" (
  echo [!] Ollama_Start.bat liegt nicht im selben Ordner wie diese Datei.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop');" ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Sulaiman Durrani KI-Agent.lnk'));" ^
  "$s.TargetPath='%~dp0Ollama_Start.bat';" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.WindowStyle=7;" ^
  "$s.Description='Sulaiman Durrani Open Source KI-Agent starten';" ^
  "$ico=Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'; if(Test-Path $ico){$s.IconLocation=$ico+',0'};" ^
  "$s.Save(); Write-Host ('Verknuepfung erstellt: ' + (Join-Path $d 'Sulaiman Durrani KI-Agent.lnk'))"
if errorlevel 1 (
  echo [!] Verknuepfung konnte nicht erstellt werden.
) else (
  echo Fertig. Du kannst den Chat jetzt ueber "Sulaiman Durrani KI-Agent" auf dem Desktop starten.
)
pause
