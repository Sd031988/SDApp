"""
SULAIMAN DURRANI OPEN SOURCE KI-AGENT – Launcher (Windows), entwickelt von Sulaiman Durrani

- Prüft, ob Ollama läuft (Port 11434), und startet es sonst im Hintergrund.
- Startet eine eigene Chat-Oberfläche auf http://localhost:8765 und öffnet den Browser.
- Läuft der Launcher schon, wird nur der Browser geöffnet (kein zweiter Server).
- Über Ollama_Start.bat läuft er unsichtbar im Hintergrund (pythonw);
  beenden mit dem Knopf „Beenden“ im Chat. Fehler erscheinen als Meldungsfenster.

Nur Python-Standardbibliothek, keine Zusatzpakete.
"""

import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from functools import partial
from http.server import BaseHTTPRequestHandler, SimpleHTTPRequestHandler, ThreadingHTTPServer

OLLAMA = "http://127.0.0.1:11434"
UI_PORT = 8765
MARKER = "/__ollama_launcher"

# Diese Ollama-Endpunkte reicht die Oberfläche durch
PROXY = {
    ("GET", "/api/tags"), ("GET", "/api/version"), ("GET", "/api/ps"),
    ("POST", "/api/chat"), ("POST", "/api/pull"), ("POST", "/api/show"), ("POST", "/api/generate"),
    ("DELETE", "/api/delete"),
}

DETACHED = 0x00000008
NEW_GROUP = 0x00000200
NO_WINDOW = 0x08000000


# ------------------------------------------------------------------ Ollama
def ollama_up():
    try:
        with urllib.request.urlopen(OLLAMA + "/api/version", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def find_ollama():
    exe = shutil.which("ollama")
    if exe:
        return exe
    p = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe")
    return p if os.path.isfile(p) else None


def ensure_ollama():
    if ollama_up():
        print("[OK] Ollama läuft.")
        return True
    exe = find_ollama()
    if not exe:
        print("[!] Ollama nicht gefunden. Installieren: https://ollama.com/download")
        return False
    print("[+] Starte Ollama", end="", flush=True)
    flags = DETACHED | NEW_GROUP | NO_WINDOW if os.name == "nt" else 0
    # Die Ollama-App startet ihren eigenen Server. Läuft zusätzlich "ollama serve",
    # kämpfen zwei Server um Port 11434 (App startet dann im Sekundentakt neu).
    app = os.path.join(os.path.dirname(exe), "ollama app.exe")
    cmd = [app] if os.name == "nt" and os.path.isfile(app) else [exe, "serve"]
    subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     stdin=subprocess.DEVNULL, creationflags=flags)
    for _ in range(30):
        if ollama_up():
            print(" OK")
            return True
        print(".", end="", flush=True)
        time.sleep(1)
    print("\n[!] Ollama antwortet nicht auf Port 11434.")
    return False


# ------------------------------------------------------------------ Oberfläche
PAGE = r"""<!doctype html>
<html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sulaiman Durrani Open Source KI-Agent</title>
<style>
:root{--bg:#f5f5f2;--side:#ecebe6;--panel:#fff;--text:#1c1c1a;--muted:#6d6c66;--line:#dedcd5;
--accent:#1f5596;--accentText:#fff;--me:#1f5596;--code:#f0efea;--danger:#b3261e;--hover:#e2e0d9}
@media (prefers-color-scheme:dark){:root{--bg:#171716;--side:#1e1e1c;--panel:#242422;--text:#ecebe7;
--muted:#9b9a93;--line:#373632;--accent:#5c95dc;--accentText:#0d1724;--me:#2c5f9e;--code:#1b1b19;--danger:#ef6b62;--hover:#2d2d2a}}
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--text);font:15px/1.55 system-ui,"Segoe UI",sans-serif;display:flex;overflow:hidden}
button,select,textarea,input{font:inherit;color:inherit}
button{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:6px 12px;cursor:pointer}
button:hover:not(:disabled){background:var(--hover)}
button.primary{background:var(--accent);border-color:var(--accent);color:var(--accentText)}
button.primary:hover:not(:disabled){filter:brightness(1.08);background:var(--accent)}
button.ghost{border-color:transparent;background:transparent}
button.danger{color:var(--danger)}
button:disabled{opacity:.45;cursor:default}
select,input,textarea{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:6px 8px}
#side{width:260px;flex:none;background:var(--side);border-right:1px solid var(--line);display:flex;flex-direction:column}
#side .top{padding:12px;display:flex;gap:8px}
#side .top button{flex:1}
#chats{flex:1;overflow-y:auto;padding:0 8px 12px}
.chat{display:flex;align-items:center;gap:4px;padding:7px 8px;border-radius:8px;cursor:pointer;color:var(--text)}
.chat:hover{background:var(--hover)}.chat.active{background:var(--panel);box-shadow:0 0 0 1px var(--line)}
.chat span{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:14px}
.chat button{padding:2px 6px;opacity:0;font-size:13px}.chat:hover button,.chat.active button{opacity:.7}
#side .foot{padding:10px 12px;border-top:1px solid var(--line);font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:8px}
#search{margin:0 12px 10px;width:calc(100% - 24px)}
#quit{width:100%}
.imgs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px;justify-content:flex-end}
.imgs img{width:96px;height:96px;object-fit:cover;border-radius:10px;border:1px solid var(--line);cursor:zoom-in}
#attach{display:flex;gap:6px;flex-wrap:wrap;padding:0 0 6px}
#attach:empty{display:none}
#attach .th{position:relative}
#attach img{width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--line);display:block}
#attach button{position:absolute;top:-6px;right:-6px;width:20px;height:20px;padding:0;border-radius:50%;font-size:11px;line-height:1}
#box.drop{outline:2px dashed var(--accent);outline-offset:2px}
#clip{padding:6px 9px}
#viewer{padding:0;width:auto;max-width:95vw;background:transparent;border:none}
#viewer img{max-width:95vw;max-height:90vh;display:block;border-radius:10px}
.agentsw{display:flex;align-items:center;gap:5px;font-size:14px;padding:5px 10px;border:1px solid var(--line);border-radius:8px;cursor:pointer;user-select:none;white-space:nowrap}
body.agent .agentsw{border-color:#c77d14;color:#c77d14;font-weight:600}
body.agent #box{border-color:#c77d14}
.row.tool{margin:6px 0}
.toolcard{font-size:13px;border:1px solid var(--line);border-left:3px solid #2e9d5b;border-radius:8px;background:var(--panel);padding:6px 10px}
.toolcard.denied{border-left-color:var(--danger)}
.toolcard summary{cursor:pointer;color:var(--muted);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.toolcard summary .tn{color:var(--text);font-weight:600}
.toolcard pre{white-space:pre-wrap;max-height:300px;overflow:auto;margin:6px 0 0;font:12px/1.45 Consolas,monospace;background:var(--code);padding:8px;border-radius:6px}
.approve{border:2px solid #c77d14;border-radius:12px;background:var(--panel);padding:12px 14px;margin:12px 0}
.approve .ah{font-size:14px;margin-bottom:6px}
.approve .ac{white-space:pre-wrap;max-height:260px;overflow:auto;font:13px/1.45 Consolas,monospace;background:var(--code);padding:8px 10px;border-radius:8px;margin:0 0 10px}
.approve .ab{display:flex;gap:8px}
dialog label input[type=checkbox]{margin-right:6px}
.plan{border:1px solid var(--line);border-radius:10px;background:var(--panel);padding:8px 12px;font-size:14px}
.plan .pt{font-size:12px;color:var(--muted);font-weight:600;margin-bottom:2px}
.plan ul{list-style:none;margin:0;padding:0}.plan li{padding:2px 0}.plan li.done{color:var(--muted);text-decoration:line-through}
.preview{border:1px solid var(--line);border-radius:10px;overflow:hidden;background:var(--panel);margin-top:6px}
.preview .pbar{display:flex;justify-content:space-between;padding:6px 10px;font-size:12px;color:var(--muted);border-bottom:1px solid var(--line)}
.preview .pbar a{color:var(--accent)}
.preview iframe{display:block;width:100%;height:420px;border:0;background:#fff}
.sumcard{border:1px solid #2e9d5b;border-left-width:4px;border-radius:10px;background:var(--panel);padding:10px 14px;font-size:14px}
.sumcard .st{font-weight:600;margin-bottom:4px}.sumcard ul{margin:0;padding-left:1.2em}.sumcard li{margin:2px 0;overflow-wrap:anywhere}
.sumcard code{font:12px Consolas,monospace}.sumcard small{color:var(--muted)}.sumcard a{color:var(--accent);font-size:13px}
.approve .ab{flex-wrap:wrap}
.notecard{font-size:13px;color:#a8670f;background:rgba(199,125,20,.08);border:1px dashed #c77d14;border-radius:8px;padding:6px 10px}
.tabs{display:flex;gap:4px;margin:0 12px 10px;background:var(--hover);border-radius:9px;padding:3px}
.tabs button{flex:1;border:none;background:transparent;padding:5px;font-size:13px}
.tabs button.on{background:var(--panel);box-shadow:0 1px 2px rgba(0,0,0,.12)}
#projects{flex:1;overflow-y:auto;padding:0 8px 12px}
.proj{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 10px;margin-bottom:8px}
.proj .pn{font-weight:600;font-size:14px;overflow-wrap:anywhere}.proj .pm{font-size:12px;color:var(--muted);margin:2px 0 6px}
.proj .pb{display:flex;flex-wrap:wrap;gap:4px}.proj .pb button{padding:2px 8px;font-size:12px}
.sumbtns{margin-top:8px}.sumbtns:empty{display:none}
.sumcard button.mini{padding:0 6px;font-size:11px;margin-left:6px}
.sumcard li.undone code{text-decoration:line-through;color:var(--muted)}
.sumcard.undone{border-color:var(--muted)}
#mic{padding:6px 9px}#mic.rec{color:#fff;background:var(--danger);border-color:var(--danger);animation:pulse 1.2s infinite}
@keyframes pulse{50%{opacity:.6}}
#speed{margin-left:8px;font-size:12px;padding:1px 7px;border-radius:10px;cursor:help}
#speed:empty{display:none}#speed.fast{background:rgba(46,157,91,.15);color:#2e9d5b}
#speed.mid{background:rgba(199,125,20,.15);color:#c77d14}#speed.slow{background:rgba(179,38,30,.15);color:var(--danger)}
@media (max-width:760px){#status .txt{display:none}}
.shots{display:flex;gap:8px;margin:6px 0;align-items:flex-start}.shots img{max-height:180px;max-width:48%;border:1px solid var(--line);border-radius:6px;cursor:zoom-in;background:#fff}
.proj.running{border-color:#2e9d5b}
.brand{padding:14px 14px 2px;line-height:1.25}.brand b{display:block;font-size:15px}.brand span{font-size:12px;color:var(--muted)}
.empty .eb{font-size:13px;letter-spacing:.04em;text-transform:uppercase;color:var(--accent);font-weight:600;margin-bottom:8px}
.bye{margin:auto;text-align:center;color:var(--muted);padding:24px}
#main{flex:1;display:flex;flex-direction:column;min-width:0}
header{display:flex;gap:8px;align-items:center;padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel)}
#menu{display:none}
#model{max-width:260px;min-width:0}
#status{font-size:13px;color:var(--muted);margin-right:auto;display:flex;align-items:center;gap:6px;white-space:nowrap}
.dot{width:8px;height:8px;border-radius:50%;background:var(--muted)}.dot.ok{background:#2e9d5b}.dot.bad{background:var(--danger)}
#log{flex:1;overflow-y:auto}
#inner{max-width:820px;margin:0 auto;padding:20px 16px 8px}
.empty{color:var(--muted);text-align:center;margin-top:18vh}
.empty h2{color:var(--text);font-weight:600;margin:0 0 6px}
.row{margin:14px 0;display:flex;flex-direction:column}
.row.user{align-items:flex-end}
.bubble{max-width:88%;padding:10px 14px;border-radius:14px;overflow-wrap:anywhere}
.user .bubble{background:var(--me);color:#fff;white-space:pre-wrap}
.bot .bubble{background:var(--panel);border:1px solid var(--line);max-width:100%}
.bot .bubble.err{border-color:var(--danger);color:var(--danger)}
.meta{font-size:12px;color:var(--muted);margin:4px 6px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.meta button{padding:1px 8px;font-size:12px}
.bubble p{margin:.4em 0}.bubble p:first-child{margin-top:0}.bubble p:last-child{margin-bottom:0}
.bubble h1,.bubble h2,.bubble h3,.bubble h4{margin:.8em 0 .3em;line-height:1.3}
.bubble h1{font-size:1.3em}.bubble h2{font-size:1.18em}.bubble h3,.bubble h4{font-size:1.05em}
.bubble ul,.bubble ol{margin:.4em 0;padding-left:1.4em}
.bubble code{background:var(--code);padding:1px 5px;border-radius:5px;font:13px/1.5 Consolas,"Cascadia Code",monospace}
.bubble pre{background:var(--code);border:1px solid var(--line);border-radius:10px;margin:.6em 0;overflow:hidden}
.bubble pre .bar{display:flex;justify-content:space-between;align-items:center;padding:4px 10px;font-size:12px;color:var(--muted);border-bottom:1px solid var(--line)}
.bubble pre .bar button{padding:1px 8px;font-size:12px}
.bubble pre code{display:block;padding:10px 12px;overflow-x:auto;background:none;white-space:pre}
.bubble blockquote{margin:.5em 0;padding-left:10px;border-left:3px solid var(--line);color:var(--muted)}
.bubble a{color:var(--accent)}
.bubble table{border-collapse:collapse;margin:.5em 0;display:block;overflow-x:auto}
.bubble th,.bubble td{border:1px solid var(--line);padding:4px 8px;text-align:left}
details.think{margin-bottom:8px;font-size:13px;color:var(--muted);border-left:3px solid var(--line);padding-left:10px}
details.think summary{cursor:pointer;user-select:none}
details.think div{white-space:pre-wrap;margin-top:4px}
.cursor::after{content:"\258D";animation:blink 1s steps(1) infinite;color:var(--muted)}
@keyframes blink{50%{opacity:0}}
#composer{max-width:820px;width:100%;margin:0 auto;padding:8px 16px 14px}
#box{display:flex;gap:8px;align-items:flex-end;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:8px}
#t{flex:1;border:none;resize:none;outline:none;max-height:220px;min-height:24px;padding:6px;background:transparent}
#hint{font-size:12px;color:var(--muted);text-align:center;margin-top:6px}
dialog{border:1px solid var(--line);border-radius:14px;background:var(--panel);color:var(--text);padding:0;width:min(560px,calc(100vw - 32px))}
dialog::backdrop{background:rgba(0,0,0,.4)}
dialog .head{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid var(--line)}
dialog .head h3{margin:0;font-size:16px}
dialog .body{padding:16px 18px;max-height:70vh;overflow-y:auto}
dialog label{display:block;font-size:13px;font-weight:600;margin:14px 0 4px}dialog .body>label:first-child{margin-top:0}
dialog .help{font-size:12px;color:var(--muted);margin-top:3px}
dialog textarea{width:100%;min-height:90px;resize:vertical}
.line{display:flex;gap:8px;align-items:center}
.line input[type=text]{flex:1;min-width:0}
.mlist{margin-top:14px;border-top:1px solid var(--line)}
.mitem{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)}
.mitem span{flex:1;overflow-wrap:anywhere}.mitem small{color:var(--muted)}
progress{width:100%;height:8px;margin-top:8px}
#pullmsg{font-size:13px;color:var(--muted);margin-top:4px;min-height:1.2em}
@media (max-width:760px){
  #side{position:fixed;inset:0 auto 0 0;z-index:5;transform:translateX(-100%);transition:transform .2s;box-shadow:0 0 30px rgba(0,0,0,.3)}
  body.open #side{transform:none}
  #menu{display:inline-block}
  header{padding:8px 10px;gap:6px}
  #model{max-width:38vw}
  #status .txt{display:none}
}
</style></head><body>
<aside id="side">
  <div class="brand"><b>Sulaiman Durrani</b><span>Open Source KI-Agent</span></div>
  <div class="top"><button class="primary" id="newchat">+ Neuer Chat</button></div>
  <div class="tabs"><button id="tabChats" class="on">Chats</button><button id="tabProj">Projekte</button></div>
  <input type="search" id="search" placeholder="Chats durchsuchen…" aria-label="Chats durchsuchen">
  <div id="chats"></div>
  <div id="projects" hidden></div>
  <div class="foot"><button id="quit" title="Launcher und Chat-Server beenden">Beenden</button>
  <span>Chats werden nur in diesem Browser gespeichert.</span></div>
</aside>
<div id="main">
  <header>
    <button class="ghost" id="menu" aria-label="Chats">&#9776;</button>
    <span id="status"><span class="dot" id="dot"></span><span class="txt" id="stxt">verbinde…</span><span id="speed"></span></span>
    <label class="agentsw" title="Agent-Modus: Das Modell darf mit deiner Erlaubnis Aktionen auf dem PC ausführen"><input type="checkbox" id="agent"> Agent</label>
    <select id="model" aria-label="Modell"></select>
    <button id="btnModels" title="Modelle verwalten">Modelle</button>
    <button id="btnExport" title="Chat als Markdown-Datei speichern" aria-label="Chat exportieren">&#8615;</button>
    <button id="btnSettings" title="Einstellungen" aria-label="Einstellungen">&#9881;</button>
  </header>
  <div id="log"><div id="inner"></div></div>
  <div id="composer">
    <div id="attach"></div>
    <div id="box">
      <button class="ghost" id="clip" title="Bild anhängen (nur für Bild-Modelle wie qwen2.5vl, llava, gemma3)" aria-label="Bild anhängen">&#128206;</button>
      <input type="file" id="file" accept="image/*" multiple hidden>
      <textarea id="t" rows="1" placeholder="Nachricht an das Modell…"></textarea>
      <button class="ghost" id="mic" title="Spracheingabe" aria-label="Spracheingabe">&#127908;</button>
      <button class="primary" id="send">Senden</button>
      <button id="stop" hidden>Stopp</button>
    </div>
    <div id="hint">Enter = senden · Shift+Enter = neue Zeile · Bilder auch per Einfügen oder Hineinziehen</div>
  </div>
</div>

<dialog id="viewer"><img alt="Bild"></dialog>
<dialog id="dlgVersions"><div class="head"><h3 id="vtitle">Versionen</h3><button class="ghost" data-close>&#10005;</button></div>
<div class="body"><div class="help" style="margin-bottom:8px">Nach jedem Auftrag des Agenten wird automatisch eine Version gespeichert (Git).</div><div class="mlist" id="vlist"></div></div></dialog>
<dialog id="dlgToken"><div class="head"><h3>GitHub-Zugang einrichten</h3><button class="ghost" data-close>&#10005;</button></div>
<div class="body"><div class="help" style="font-size:13px;line-height:1.5">Zum Veröffentlichen braucht der Launcher einen GitHub-Token (einmalig):<br>
1. Öffne <a href="https://github.com/settings/tokens/new?scopes=repo&amp;description=Ollama%20Launcher" target="_blank" rel="noopener">github.com/settings/tokens/new</a> (bei GitHub angemeldet sein).<br>
2. Haken bei <b>repo</b> ist schon gesetzt. Ablaufdatum wählen, unten auf <b>Generate token</b>.<br>
3. Den Token (beginnt mit <code>ghp_</code>) kopieren und hier einfügen.<br>
Der Token wird nur auf deinem PC gespeichert (<code>%USERPROFILE%\.ollama_launcher</code>) und nur an GitHub gesendet.</div>
<label for="tok">Token</label><div class="line"><input type="password" id="tok" autocomplete="off" style="flex:1"><button class="primary" id="tokSave">Speichern</button></div></div></dialog>
<dialog id="dlgSettings"><div class="head"><h3>Einstellungen</h3><button class="ghost" data-close>&#10005;</button></div>
<div class="body">
  <label for="sys">System-Prompt</label>
  <textarea id="sys" placeholder="z.B. Du bist ein hilfreicher Assistent. Antworte immer auf Deutsch."></textarea>
  <div class="help">Gilt für alle neuen Nachrichten in allen Chats.</div>
  <label for="temp">Temperatur: <span id="tempv"></span></label>
  <div class="line"><input type="range" id="temp" min="0" max="2" step="0.05" style="flex:1"><button id="tempReset">Standard</button></div>
  <div class="help">Niedrig = genauer und vorhersehbar, hoch = kreativer.</div>
  <label><input type="checkbox" id="autoRead"> Agent: Lesen ohne Nachfrage erlauben</label>
  <div class="help">Ordner anzeigen, Dateien lesen und Internetsuche laufen dann ohne Klick. Schreiben, Befehle und Öffnen fragen immer.</div>
  <label><input type="checkbox" id="think"> Modell vorher nachdenken lassen</label>
  <div class="help">Nur für Denk-Modelle wie qwen3 oder deepseek-r1. Gründlicher, aber oft 2–5× langsamer. Standard: aus.</div>
  <label><input type="checkbox" id="designCheck"> Agent: Design per Screenshot prüfen</label>
  <div class="help">Der Agent macht Screenshots (Computer + Handy) und lässt sie von einem Bild-Modell begutachten. Bessere Ergebnisse, kostet aber etwas Zeit.</div>
  <label for="voiceLang">Sprache der Spracheingabe</label>
  <select id="voiceLang"><option value="de-DE">Deutsch</option><option value="en-US">English</option></select>
  <label for="ctx">Kontextlänge</label>
  <select id="ctx"><option value="">Automatisch (lokal 12288, Cloud 32768)</option><option>2048</option><option>4096</option><option>8192</option><option>16384</option><option>32768</option></select>
  <div class="help">Wie viel vom Chat das Modell auf einmal sieht. Mehr braucht mehr Arbeitsspeicher.</div>
</div></dialog>

<dialog id="dlgModels"><div class="head"><h3>Modelle</h3><button class="ghost" data-close>&#10005;</button></div>
<div class="body">
  <label for="pullname">Modell herunterladen</label>
  <div class="line"><input type="text" id="pullname" placeholder="z.B. qwen3:8b oder llama3.2"><button class="primary" id="pullbtn">Laden</button></div>
  <div class="help">Namen findest du auf ollama.com/library</div>
  <progress id="pullbar" max="100" value="0" hidden></progress>
  <div id="pullmsg"></div>
  <div class="mlist" id="mlist"></div>
</div></dialog>

<script>
const $=id=>document.getElementById(id);
const store={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},
             set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let chats=store.get("oc_chats",[]), settings=Object.assign({system:"",temperature:null,num_ctx:"",agent:false,autoRead:false},store.get("oc_settings",{}));
let current=store.get("oc_current",null), ctrl=null, models=[];
let warnedFull=false;
const save=()=>{
  try{localStorage.setItem("oc_chats",JSON.stringify(chats));localStorage.setItem("oc_current",JSON.stringify(current))}
  catch(e){if(!warnedFull){warnedFull=true;alert("Der Browser-Speicher ist voll (meist wegen vieler Bilder). Neue Nachrichten werden nicht mehr gespeichert. Lösche alte Chats, um Platz zu schaffen.")}}
};
const chat=()=>chats.find(c=>c.id===current);

/* ---------- Markdown (sicher: erst escapen, dann formatieren) ---------- */
const esc=s=>s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
function inline(s){
  const codes=[];s=s.replace(/`([^`\n]+)`/g,(m,c)=>{codes.push(c);return "\u0000"+(codes.length-1)+"\u0000"});
  s=s.replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>").replace(/(^|[^*])\*([^*\n]+)\*/g,"$1<em>$2</em>")
     .replace(/\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener">$1</a>');
  return s.replace(/\u0000(\d+)\u0000/g,(m,i)=>"<code>"+codes[i]+"</code>");
}
function md(src){
  const parts=src.split(/^\s*```/m);let html="";
  parts.forEach((p,i)=>{
    if(i%2){const nl=p.indexOf("\n");const lang=nl<0?p.trim():p.slice(0,nl).trim();const code=nl<0?"":p.slice(nl+1).replace(/\n\s*$/,"");
      html+='<pre><div class="bar"><span>'+esc(lang||"code")+'</span><button data-copy>Kopieren</button></div><code>'+esc(code)+"</code></pre>";return}
    const lines=esc(p).split("\n");let list=null,para=[],tbl=[];
    const flushP=()=>{if(para.length){html+="<p>"+inline(para.join("<br>"))+"</p>";para=[]}};
    const flushL=()=>{if(list){html+="</"+list+">";list=null}};
    const flushT=()=>{if(!tbl.length)return;const rows=tbl.filter(r=>!/^\|?[\s:|-]+\|?$/.test(r));
      html+="<table>"+rows.map((r,ri)=>"<tr>"+r.replace(/^\||\|$/g,"").split("|").map(c=>ri?"<td>"+inline(c.trim())+"</td>":"<th>"+inline(c.trim())+"</th>").join("")+"</tr>").join("")+"</table>";tbl=[]};
    for(const l of lines){
      let m;
      if(/^\s*\|.*\|\s*$/.test(l)){flushP();flushL();tbl.push(l.trim());continue}else flushT();
      if(m=l.match(/^(#{1,4})\s+(.*)/)){flushP();flushL();html+="<h"+m[1].length+">"+inline(m[2])+"</h"+m[1].length+">"}
      else if(m=l.match(/^\s*[-*•]\s+(.*)/)){flushP();if(list!=="ul"){flushL();html+="<ul>";list="ul"}html+="<li>"+inline(m[1])+"</li>"}
      else if(m=l.match(/^\s*\d+[.)]\s+(.*)/)){flushP();if(list!=="ol"){flushL();html+="<ol>";list="ol"}html+="<li>"+inline(m[1])+"</li>"}
      else if(m=l.match(/^&gt;\s?(.*)/)){flushP();flushL();html+="<blockquote>"+inline(m[1])+"</blockquote>"}
      else if(!l.trim()){flushP();flushL()}
      else{flushL();para.push(l)}
    }
    flushP();flushL();flushT();
  });
  return html;
}
/* <think>…</think> aus dem Text herauslösen (Qwen3, DeepSeek-R1 usw.) */
function splitThink(text){
  let think="";
  const out=text.replace(/<think>([\s\S]*?)(<\/think>|$)/g,(m,t)=>{think+=t;return ""});
  return {think:think.trim(),answer:out.replace(/^\s+/,"")};
}

/* ---------- Anzeige ---------- */
function renderList(){
  const box=$("chats");box.innerHTML="";
  const q=$("search").value.trim().toLowerCase();
  const list=[...chats].sort((a,b)=>b.updated-a.updated).filter(c=>!q||(c.title||"").toLowerCase().includes(q)||
    c.messages.some(m=>(m.content||"").toLowerCase().includes(q)));
  if(q&&!list.length)box.innerHTML='<div class="help" style="padding:8px">Nichts gefunden.</div>';
  list.forEach(c=>{
    const d=document.createElement("div");d.className="chat"+(c.id===current?" active":"");
    d.innerHTML="<span></span><button title='Umbenennen'>&#9998;</button><button title='Löschen' class='danger'>&#10005;</button>";
    d.querySelector("span").textContent=c.title||"Neuer Chat";
    d.onclick=()=>{if(ctrl)return;current=c.id;save();renderAll();document.body.classList.remove("open")};
    const [ren,del]=d.querySelectorAll("button");
    ren.onclick=e=>{e.stopPropagation();const t=prompt("Neuer Name:",c.title||"");if(t&&t.trim()){c.title=t.trim();save();renderList()}};
    del.onclick=e=>{e.stopPropagation();if(ctrl&&c.id===current)return;if(!confirm("Chat löschen?"))return;
      chats=chats.filter(x=>x.id!==c.id);if(current===c.id)current=null;save();renderAll()};
    box.appendChild(d);
  });
}
function previewUrlFor(path){
  if(!INFO.preview_port)return null;const base=INFO.projects.replace(/[\\\/]+$/,"");
  if(path.toLowerCase().indexOf(base.toLowerCase())!==0)return null;
  return "http://localhost:"+INFO.preview_port+"/"+path.slice(base.length+1).split(/[\\\/]/).map(encodeURIComponent).join("/")}
function previewCard(url,isApp){
  const w=document.createElement("div");w.className="preview";
  w.innerHTML='<div class="pbar"><span>Vorschau</span><a target="_blank" rel="noopener">Im Browser öffnen &#8599;</a></div><iframe sandbox="allow-scripts allow-forms allow-modals allow-downloads allow-pointer-lock" allow="fullscreen; autoplay; gamepad" loading="lazy"></iframe>';
  if(isApp){w.querySelector("iframe").setAttribute("sandbox","allow-scripts allow-forms allow-modals allow-downloads allow-same-origin allow-popups");w.querySelector(".pbar span").textContent="Laufende App: "+url}
  w.querySelector("a").href=url;w.querySelector("iframe").src=url;return w}
function msgNode(m,streaming){
  if(m.hidden){const r=document.createElement("div");r.style.display="none";return r}
  if(m.role==="note"){const r=document.createElement("div");r.className="row note";const d=document.createElement("div");d.className="notecard";
    d.textContent=m.content;r.appendChild(d);return r}
  if(m.role==="summary"){const row=document.createElement("div");row.className="row summary";
    const d=document.createElement("div");d.className="sumcard";
    d.innerHTML="<div class='st'></div><ul></ul><div class='sumbtns'></div>";
    const allUndone=m.files.every(f=>f.undone);
    d.querySelector(".st").textContent=allUndone?"\u21A9 Alles rückgängig gemacht":(m.stopped?"\u23F8 Angehalten – bisher ":"\u2705 Erledigt – ")+m.files.length+(m.files.length===1?" Datei":" Dateien")+" erstellt/geändert";
    if(allUndone)d.classList.add("undone");
    const ul=d.querySelector("ul");
    const doUndo=async(list,btn)=>{const ids=list.filter(f=>!f.undone).flatMap(f=>f.undo||[]);if(!ids.length)return;
      btn.disabled=true;const r=await undoIds(ids);
      list.forEach(f=>{if((f.undo||[]).length&&f.undo.every(u=>r.done.has(u)))f.undone=true});save();renderMessages();
      if(!r.ok)alert("Nicht alles konnte rückgängig gemacht werden:\n\n"+r.messages.filter(x=>/^Nicht/.test(x)).join("\n"))};
    const canUndo=m.files.some(f=>!f.undone&&f.undo&&f.undo.length);
    if(canUndo){const b=document.createElement("button");b.textContent="\u21A9 Alles rückgängig";b.title="Alle Dateien dieses Auftrags auf den Stand davor zurücksetzen";
      b.onclick=()=>{if(confirm("Alle Änderungen dieses Auftrags rückgängig machen?\nNeu erstellte Dateien werden entfernt, geänderte auf den alten Stand gesetzt."))doUndo(m.files,b)};d.querySelector(".sumbtns").appendChild(b)}
    m.files.forEach(f=>{const li=document.createElement("li");const code=document.createElement("code");code.textContent=f.path;
      const k=document.createElement("small");k.textContent=" "+(f.undone?"rückgängig gemacht":f.kind);li.appendChild(code);li.appendChild(k);if(f.undone)li.classList.add("undone");
      if(!f.undone&&f.undo&&f.undo.length){const ub=document.createElement("button");ub.className="mini";ub.textContent="rückgängig";ub.onclick=()=>doUndo([f],ub);li.appendChild(ub)}
      const u=!f.undone&&/\.html?$/i.test(f.path)&&previewUrlFor(f.path);
      if(u){const a=document.createElement("a");a.href=u;a.target="_blank";a.rel="noopener";a.textContent=" ansehen \u2197";li.appendChild(a)}
      ul.appendChild(li)});
    row.appendChild(d);if(m.preview&&!m.stopped&&!allUndone)row.appendChild(previewCard(m.preview,!!m.app));return row}
  if(m.role==="tool"&&m.tool_name==="update_plan"&&m.plan){const row=document.createElement("div");row.className="row tool";
    const d=document.createElement("div");d.className="plan";d.innerHTML="<div class='pt'>Plan</div><ul></ul>";
    m.plan.forEach(st=>{const li=document.createElement("li");const t=typeof st==="string"?st:(st.text||st.step||"");const done=!!(st&&st.done);
      li.className=done?"done":"";li.textContent=(done?"\u2611 ":"\u2610 ")+t;d.querySelector("ul").appendChild(li)});
    row.appendChild(d);return row}
  if(m.role==="tool"&&m.app_url){const row=document.createElement("div");row.className="row tool";
    const d=document.createElement("details");d.className="toolcard";d.innerHTML="<summary><span class='tn'></span> <code></code></summary><pre></pre>";
    d.querySelector(".tn").textContent="\u2714 "+(TOOL_LABEL[m.tool_name]||m.tool_name);d.querySelector("code").textContent=argText(m.tool_name,m.args).slice(0,120);
    d.querySelector("pre").textContent=m.content;row.appendChild(d);row.appendChild(previewCard(m.app_url,true));return row}
  if(m.role==="tool"&&m.tool_name==="show_preview"&&m.preview){const row=document.createElement("div");row.className="row tool";
    row.appendChild(previewCard(m.preview));return row}
  if(m.role==="tool"){const row=document.createElement("div");row.className="row tool";
    const d=document.createElement("details");d.className="toolcard"+(m.denied?" denied":"");
    d.innerHTML="<summary><span class='tn'></span> <code></code></summary><pre></pre>";
    d.querySelector(".tn").textContent=(m.denied?"\u2716 abgelehnt: ":"\u2714 ")+(TOOL_LABEL[m.tool_name]||m.tool_name);
    d.querySelector("code").textContent=argText(m.tool_name,m.args).split("\n")[0].slice(0,120);
    d.querySelector("pre").textContent=m.content;
    if(m.screens&&m.screens.length){d.open=true;const g=document.createElement("div");g.className="shots";
      m.screens.forEach(u=>{const i=document.createElement("img");i.src=u;i.alt="Screenshot";i.loading="lazy";i.onclick=()=>{$("viewer").querySelector("img").src=u;$("viewer").showModal()};g.appendChild(i)});
      d.insertBefore(g,d.querySelector("pre"))}
    row.appendChild(d);return row}
  const row=document.createElement("div");row.className="row "+(m.role==="user"?"user":"bot");
  const b=document.createElement("div");b.className="bubble";row.appendChild(b);
  if(m.role==="user"){
    if(m.images&&m.images.length){const g=document.createElement("div");g.className="imgs";
      m.images.forEach(src=>{const i=document.createElement("img");i.src="data:image/jpeg;base64,"+src;i.alt="Bild";
        i.onclick=()=>{$("viewer").querySelector("img").src=i.src;$("viewer").showModal()};g.appendChild(i)});row.insertBefore(g,b)}
    if(m.content)b.textContent=m.content;else b.remove();
    return row}
  fillBot(row,m,streaming);
  return row;
}
function fillBot(row,m,streaming){
  const b=row.querySelector(".bubble");b.className="bubble"+(m.error?" err":"");
  if(m.error){b.textContent="Fehler: "+m.error}
  else{
    const s=splitThink(m.content||"");const think=((m.thinking||"")+(s.think?"\n"+s.think:"")).trim();
    const old=b.querySelector("details.think");const userToggled=old&&old.dataset.user==="1";
    const open=userToggled?old.open:(streaming&&!s.answer);
    let h="";
    if(think)h+='<details class="think"'+(open?" open":"")+(userToggled?' data-user="1"':"")+'><summary>'+(streaming&&!s.answer?"denkt nach…":"Gedankengang anzeigen")+'</summary><div>'+esc(think)+"</div></details>";
    h+=s.answer?md(s.answer):(streaming?"":(think?"":(m.tool_calls?"<em>plant eine Aktion…</em>":"<em>(leere Antwort)</em>")));
    b.innerHTML=h;
    const d=b.querySelector("details.think");if(d)d.querySelector("summary").onclick=()=>{d.dataset.user="1"};
    if(streaming){const last=b.lastElementChild;(last&&!last.matches("details,pre,table")?last:b).classList.add("cursor")}
  }
  let meta=row.querySelector(".meta");
  if(!meta){meta=document.createElement("div");meta.className="meta";row.appendChild(meta)}
  meta.innerHTML="";
  if(streaming)return;
  if(m.model){const s=document.createElement("span");s.textContent=m.model;meta.appendChild(s)}
  if(m.stats){const s=document.createElement("span");s.textContent=m.stats;meta.appendChild(s)}
  if(!m.error&&m.content){const c=document.createElement("button");c.textContent="Kopieren";
    c.onclick=()=>copy(splitThink(m.content).answer,c);meta.appendChild(c)}
  const cur=chat();
  if(cur&&cur.messages[cur.messages.length-1]===m){const r=document.createElement("button");r.textContent="Neu generieren";r.onclick=regenerate;meta.appendChild(r)}
}
function renderMessages(){
  const inner=$("inner");inner.innerHTML="";const c=chat();
  if(!c||!c.messages.length){inner.innerHTML='<div class="empty"><div class="eb">Sulaiman Durrani Open Source KI-Agent</div><h2>Womit kann ich helfen?</h2><div>Wähle oben ein Modell und schreib unten deine Nachricht.</div></div>';return}
  c.messages.forEach(m=>inner.appendChild(msgNode(m,false)));
  $("log").scrollTop=$("log").scrollHeight;
}
function renderAll(){renderList();renderMessages()}
function copy(text,btn){
  const done=()=>{const o=btn.textContent;btn.textContent="Kopiert ✓";setTimeout(()=>btn.textContent=o,1200)};
  const fallback=()=>{const t=document.createElement("textarea");t.value=text;document.body.appendChild(t);t.select();try{document.execCommand("copy");done()}catch(e){}t.remove()};
  if(navigator.clipboard)navigator.clipboard.writeText(text).then(done,fallback);else fallback();
}
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-copy]");if(b)copy(b.closest("pre").querySelector("code").textContent,b);
  const c=e.target.closest("[data-close]");if(c)c.closest("dialog").close();
});

/* ---------- Verbindung & Modelle ---------- */
function setStatus(ok,text){$("dot").className="dot "+(ok?"ok":"bad");$("stxt").textContent=text}
async function loadModels(){
  try{
    const r=await fetch("/api/tags");if(!r.ok)throw 0;const j=await r.json();
    models=(j.models||[]).sort((a,b)=>a.name.localeCompare(b.name));
    const sel=$("model"),keep=sel.value||store.get("oc_model","");sel.innerHTML="";
    models.forEach(m=>{const o=document.createElement("option");o.value=o.textContent=m.name;sel.appendChild(o)});
    if(models.some(m=>m.name===keep))sel.value=keep;
    if(models.length){setStatus(true,"verbunden");warmUp()}else setStatus(false,"keine Modelle – über „Modelle“ eins laden");
    renderModelList();return true;
  }catch(e){setStatus(false,"Ollama nicht erreichbar");return false}
}
let lastTps=null,warmFor="";
async function checkSpeed(){
  try{const j=await (await fetch("/api/ps")).json();const name=$("model").value;
    const m=(j.models||[]).find(x=>x.name===name||x.model===name);const el=$("speed");
    if(!m){el.textContent="";el.className="";el.title="";return}
    const pct=m.size?Math.round((m.size_vram||0)/m.size*100):0;
    let txt,cls,tip;
    if(pct>=100){txt="\u26A1 GPU";cls="fast";tip="Modell läuft komplett auf der Grafikkarte – schnellste Variante."}
    else if(pct>0){txt="\u26A0 "+pct+"% GPU";cls="mid";tip="Modell passt nicht ganz in den Grafikspeicher, "+(100-pct)+"% laufen auf dem Prozessor – deutlich langsamer. Kleineres Modell oder kleinere Kontextlänge wählen."}
    else{txt="\uD83D\uDC22 CPU";cls="slow";tip="Modell läuft nur auf dem Prozessor – sehr langsam. Grafikkarte wird nicht genutzt oder Modell ist zu groß. Kleineres Modell wählen (z.B. qwen3:4b, qwen2.5-coder:3b)."}
    if(lastTps)tip+=" Letzte Antwort: "+lastTps.toFixed(1)+" Tokens/s.";
    el.textContent=txt;el.className=cls;el.title=tip+" Größe im Speicher: "+gb(m.size)+".";
  }catch(e){}
}
async function warmUp(){
  const model=$("model").value;if(!model||isCloud(model)||warmFor===model+"|"+JSON.stringify(baseOpts(model)))return;
  warmFor=model+"|"+JSON.stringify(baseOpts(model));const el=$("speed");el.textContent="lädt Modell…";el.className="mid";el.title="Das Modell wird in den Speicher geladen, damit die erste Antwort schneller kommt.";
  try{await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model,keep_alive:KEEP,options:baseOpts(model)})})}catch(e){}
  checkSpeed();
}
$("model").onchange=()=>{store.set("oc_model",$("model").value);lastTps=null;warmUp()};
setInterval(()=>{if(!ctrl&&$("dot").classList.contains("bad"))loadModels()},5000);

function gb(n){return n>=1e9?(n/1e9).toFixed(1)+" GB":(n/1e6).toFixed(0)+" MB"}
function renderModelList(){
  const l=$("mlist");l.innerHTML="";
  if(!models.length){l.innerHTML='<div class="help" style="padding:10px 0">Noch keine Modelle installiert.</div>';return}
  models.forEach(m=>{const d=document.createElement("div");d.className="mitem";
    d.innerHTML="<span></span><small></small><button class='danger'>Löschen</button>";
    d.querySelector("span").textContent=m.name;d.querySelector("small").textContent=m.size?gb(m.size):"";
    d.querySelector("button").onclick=async()=>{
      if(!confirm(m.name+" wirklich von der Festplatte löschen?"))return;
      const r=await fetch("/api/delete",{method:"DELETE",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:m.name,name:m.name})});
      $("pullmsg").textContent=r.ok?m.name+" gelöscht.":"Löschen fehlgeschlagen: "+await r.text();loadModels()};
    l.appendChild(d)});
}
let pulling=false;
$("pullbtn").onclick=async()=>{
  const name=$("pullname").value.trim();if(!name||pulling)return;pulling=true;$("pullbtn").disabled=true;
  const bar=$("pullbar"),msg=$("pullmsg");bar.hidden=false;bar.removeAttribute("value");msg.textContent="Starte Download…";
  try{
    const r=await fetch("/api/pull",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:name,name,stream:true})});
    if(!r.ok){let t=await r.text();try{t=JSON.parse(t).error||t}catch(e){}throw new Error(t)}
    let ok=false;
    await readLines(r,j=>{
      if(j.error)throw new Error(j.error);
      if(j.total&&j.completed!=null){bar.max=j.total;bar.value=j.completed;msg.textContent=j.status+" – "+gb(j.completed)+" / "+gb(j.total)+" ("+Math.round(j.completed/j.total*100)+" %)"}
      else{msg.textContent=j.status||"";bar.removeAttribute("value")}
      if(j.status==="success")ok=true});
    msg.textContent=ok?"✓ "+name+" ist bereit.":"Download beendet.";
    if(ok){$("pullname").value="";await loadModels();const hit=models.find(m=>m.name===name||m.name===name+":latest");
      if(hit){$("model").value=hit.name;store.set("oc_model",hit.name)}}
  }catch(e){msg.textContent="Fehler: "+(e.message||e)}
  finally{pulling=false;$("pullbtn").disabled=false;bar.hidden=true}
};
$("pullname").onkeydown=e=>{if(e.key==="Enter")$("pullbtn").click()};

/* ---------- Senden ---------- */
async function readLines(resp,onLine){
  const rd=resp.body.getReader(),dec=new TextDecoder();let buf="";
  while(true){const {done,value}=await rd.read();if(done)break;
    buf+=dec.decode(value,{stream:true});const ls=buf.split("\n");buf=ls.pop();
    for(const l of ls)if(l.trim())onLine(JSON.parse(l))}
  if(buf.trim())onLine(JSON.parse(buf));
}
function busy(on){$("send").hidden=on;$("stop").hidden=!on;$("newchat").disabled=on}
/* ---------- Agent ---------- */
const AGENT_TOOLS=[
 {type:"function",function:{name:"list_dir",description:"Listet Dateien und Ordner in einem Verzeichnis auf dem Windows-PC des Nutzers.",
   parameters:{type:"object",properties:{path:{type:"string",description:"Ordnerpfad, z.B. C:\\Users\\Durra\\Desktop oder ~ für den Benutzerordner"}},required:["path"]}}},
 {type:"function",function:{name:"read_file",description:"Liest eine Textdatei vom PC.",
   parameters:{type:"object",properties:{path:{type:"string",description:"Dateipfad"}},required:["path"]}}},
 {type:"function",function:{name:"write_file",description:"Erstellt oder überschreibt eine Textdatei auf dem PC.",
   parameters:{type:"object",properties:{path:{type:"string",description:"Dateipfad"},content:{type:"string",description:"Vollständiger neuer Inhalt"}},required:["path","content"]}}},
 {type:"function",function:{name:"run_command",description:"Führt einen PowerShell-Befehl auf dem Windows-PC aus und gibt die Ausgabe zurück. Für Systeminfos, Dateien suchen, Programme steuern usw.",
   parameters:{type:"object",properties:{command:{type:"string",description:"PowerShell-Befehl"}},required:["command"]}}},
 {type:"function",function:{name:"open_item",description:"Öffnet eine Datei, einen Ordner, ein Programm oder eine Webseite (URL) auf dem PC.",
   parameters:{type:"object",properties:{target:{type:"string",description:"Pfad, Programmname (z.B. notepad) oder URL"}},required:["target"]}}},
 {type:"function",function:{name:"update_plan",description:"Zeigt dem Nutzer deinen Arbeitsplan als Checkliste. Am Anfang mit allen Schritten aufrufen, danach immer wenn ein Schritt erledigt ist.",
   parameters:{type:"object",properties:{steps:{type:"array",description:"Liste der Schritte",items:{type:"object",properties:{text:{type:"string"},done:{type:"boolean"}},required:["text","done"]}}},required:["steps"]}}},
 {type:"function",function:{name:"show_preview",description:"Zeigt dem Nutzer eine fertige HTML-Seite aus dem Projektordner als Live-Vorschau im Chat.",
   parameters:{type:"object",properties:{path:{type:"string",description:"Pfad zur HTML-Datei, z.B. meine-seite/index.html"}},required:["path"]}}}];
AGENT_TOOLS.push(
 {type:"function",function:{name:"edit_file",description:"Ändert gezielt eine Stelle in einer bestehenden Datei: ersetzt den Text 'find' (exakt wie in der Datei) durch 'replace'. Für kleine Änderungen statt die ganze Datei neu zu schreiben.",
   parameters:{type:"object",properties:{path:{type:"string"},find:{type:"string",description:"Exakter vorhandener Text"},replace:{type:"string",description:"Neuer Text"}},required:["path","find","replace"]}}},
 {type:"function",function:{name:"check_preview",description:"Testet eine HTML-Seite aus dem Projektordner im Browser: meldet JavaScript-Fehler, fehlende Dateien, Titel, Textmenge und ob die Seite zu breit ist. Nach dem Bauen IMMER aufrufen und gefundene Fehler beheben.",
   parameters:{type:"object",properties:{path:{type:"string",description:"z.B. meine-seite/index.html"}},required:["path"]}}},
 {type:"function",function:{name:"fetch_url",description:"Lädt eine Webseite aus dem Internet und gibt ihren Text zurück (z.B. Dokumentation, Inhalte, Infos).",
   parameters:{type:"object",properties:{url:{type:"string"}},required:["url"]}}},
 {type:"function",function:{name:"web_search",description:"Sucht im Internet (DuckDuckGo) und gibt Titel, Adressen und Kurztexte der Treffer zurück. Für aktuelle Infos, Fakten, Doku. Danach mit fetch_url Details lesen.",
   parameters:{type:"object",properties:{query:{type:"string",description:"Suchbegriffe"}},required:["query"]}}});
const S=(d)=>({type:"string",description:d});
AGENT_TOOLS.push(
 {type:"function",function:{name:"github_search",description:"Sucht Open-Source-Projekte auf GitHub (sortiert nach Sternen). Zeigt Sterne, Sprache, Größe und LIZENZ. Englische Suchbegriffe funktionieren am besten, z.B. 'tetris javascript' oder 'threejs racing game'.",
   parameters:{type:"object",properties:{query:S("Suchbegriffe, optional mit language:javascript"),sort:S("stars (Standard) oder updated")},required:["query"]}}},
 {type:"function",function:{name:"github_read",description:"Liest ein GitHub-Projekt: ohne path Infos, Lizenz, Dateiliste und README; mit path den Inhalt eines Ordners oder einer Datei.",
   parameters:{type:"object",properties:{repo:S("besitzer/projekt oder GitHub-URL"),path:S("optional: Datei- oder Ordnerpfad im Projekt")},required:["repo"]}}},
 {type:"function",function:{name:"github_download",description:"Lädt ein komplettes GitHub-Projekt mit freier Open-Source-Lizenz in einen neuen Ordner im Projektordner (mit Quellenangabe). Projekte ohne freie Lizenz werden abgelehnt.",
   parameters:{type:"object",properties:{repo:S("besitzer/projekt oder GitHub-URL"),folder:S("optional: Name des neuen Ordners")},required:["repo"]}}},
 {type:"function",function:{name:"hf_search",description:"Sucht auf Hugging Face nach Modellen (models), Datensätzen (datasets) oder Spaces (fertige KI-Apps mit Quellcode, spaces).",
   parameters:{type:"object",properties:{query:S("Suchbegriffe"),kind:S("models, datasets oder spaces")},required:["query"]}}},
 {type:"function",function:{name:"hf_read",description:"Liest ein Hugging-Face-Projekt: ohne path Lizenz, Dateiliste und Beschreibung; mit path den Inhalt einer Datei (z.B. app.py).",
   parameters:{type:"object",properties:{repo_id:S("besitzer/name oder URL"),kind:S("models, datasets oder spaces"),path:S("optional: Dateipfad")},required:["repo_id"]}}},
 {type:"function",function:{name:"hf_download",description:"Lädt die Dateien eines Hugging-Face-Projekts (meist ein Space mit app.py) mit freier Lizenz in einen neuen Ordner. Große Gewichtsdateien werden übersprungen.",
   parameters:{type:"object",properties:{repo_id:S("besitzer/name oder URL"),kind:S("spaces (Standard), models oder datasets"),folder:S("optional: Ordnername")},required:["repo_id"]}}});
AGENT_TOOLS.push({type:"function",function:{name:"review_design",description:"Macht Screenshots der Seite (Desktop und Handy) und lässt sie von einem Bild-Modell begutachten: meldet sichtbare Design-Probleme (Überlappungen, abgeschnittene Inhalte, schlechter Kontrast, kaputte Handy-Ansicht, fehlende Elemente). Nach erfolgreichem check_preview einmal aufrufen.",
   parameters:{type:"object",properties:{path:{type:"string",description:"z.B. meine-seite/index.html"}},required:["path"]}}});
AGENT_TOOLS.push(
 {type:"function",function:{name:"setup_project",description:"Installiert die Abhängigkeiten eines Python-Projekts (requirements.txt -> eigene .venv) und/oder Node-Projekts (package.json -> npm install).",
   parameters:{type:"object",properties:{path:S("Projektordner, z.B. meine-app")},required:["path"]}}},
 {type:"function",function:{name:"start_app",description:"Startet ein Programm im Projektordner im Hintergrund (z.B. 'python app.py', 'npm run dev', 'python -m pytest -q') und gibt nach 'wait' Sekunden Status, Ausgabe und ggf. die Web-Adresse zurück. Die .venv des Projekts wird automatisch benutzt.",
   parameters:{type:"object",properties:{path:S("Projektordner"),command:S("Befehl"),wait:{type:"number",description:"Sekunden warten (Standard 8, Tests länger)"}},required:["path","command"]}}},
 {type:"function",function:{name:"app_output",description:"Zeigt Status und neueste Ausgabe eines gestarteten Programms.",parameters:{type:"object",properties:{proc:S("Nummer, z.B. app1")},required:["proc"]}}},
 {type:"function",function:{name:"stop_app",description:"Stoppt ein gestartetes Programm.",parameters:{type:"object",properties:{proc:S("Nummer, z.B. app1")},required:["proc"]}}});
const NO_ASK=new Set(["update_plan","show_preview","check_preview","review_design","app_output","stop_app"]);
const READ_ONLY=new Set(["list_dir","read_file","web_search","github_search","github_read","hf_search","hf_read"]);
const TOOL_LABEL={list_dir:"Ordner anzeigen",read_file:"Datei lesen",write_file:"Datei schreiben",run_command:"Befehl ausführen",open_item:"Öffnen",update_plan:"Plan",show_preview:"Vorschau",edit_file:"Datei ändern",check_preview:"Seite testen",fetch_url:"Webseite abrufen",web_search:"Im Internet suchen",
  review_design:"Design prüfen (Screenshots)",setup_project:"Abhängigkeiten installieren",start_app:"Programm starten",app_output:"Programm-Ausgabe",stop_app:"Programm stoppen",github_search:"GitHub durchsuchen",github_read:"GitHub-Projekt lesen",github_download:"GitHub-Projekt herunterladen",
  hf_search:"Hugging Face durchsuchen",hf_read:"Hugging-Face-Projekt lesen",hf_download:"Hugging-Face-Projekt herunterladen"};
let INFO={projects:"~\\Ollama_Projekte",preview_port:null};
fetch("/__info").then(r=>r.json()).then(j=>INFO=j).catch(()=>{});
function agentSystem(){return "Du bist ein Agent auf dem Windows-PC des Nutzers und erledigst Aufträge selbstständig mit Werkzeugen: "+
 "list_dir, read_file, write_file, edit_file, run_command (PowerShell), open_item, web_search, fetch_url, update_plan, check_preview und show_preview. Für aktuelle Informationen nutze web_search und danach fetch_url. Jede Aktion mit Wirkung muss der Nutzer erlauben.\n"+
 "Arbeitsweise (schnell und effizient, jede Runde kostet Zeit): 1) Rufe update_plan mit allen Schritten auf (done=false). "+
 "2) Rufe MEHRERE Werkzeuge in EINER Antwort auf, z.B. alle write_file-Aufrufe für index.html, style.css und script.js zusammen und direkt danach check_preview. "+
 "3) update_plan nur noch einmal ganz am Ende mit allen Schritten erledigt. 4) Zum Schluss ein bis zwei Sätze, was du gemacht hast. Keine langen Erklärungen.\n"+
 "Webseiten und andere Projekte legst du immer in einem eigenen Unterordner von "+INFO.projects+" an (relative Pfade wie 'meine-seite/index.html' landen automatisch dort). "+
 "Schreibe vollständige, funktionierende Dateien (index.html, style.css, script.js) mit write_file - keine Platzhalter. "+
 "Wenn die Dateien geschrieben sind: rufe check_preview auf. Meldet es Fehler oder Probleme, behebe sie mit edit_file (oder write_file) und prüfe erneut, bis keine Fehler mehr da sind. "+(settings.designCheck===false?"":"Danach EINMAL review_design aufrufen (Screenshots + Bild-Prüfung) und wesentliche gemeldete Probleme beheben. ")+"Erst dann show_preview, damit der Nutzer das Ergebnis sieht.\n"+
 "Für spätere Änderungswünsche (z.B. 'mach den Header blau'): read_file, dann gezielt edit_file, dann check_preview und show_preview.\n"+
 "Spiele, 3D und Animationen: Für 3D immer Three.js so einbinden (exakt so, damit es lädt): "+
 "<script type=\"importmap\">{\"imports\":{\"three\":\"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js\",\"three/addons/\":\"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/\"}}<\/script> "+
 "und <script type=\"module\" src=\"script.js\"><\/script>; in script.js: import * as THREE from 'three'; (Steuerung: import { OrbitControls } from 'three/addons/controls/OrbitControls.js';). "+
 "2D-Spiele mit <canvas> und requestAnimationFrame. Jedes Spiel braucht: Startbildschirm, Punkte/Highscore (localStorage), Game-Over mit Neustart, Steuerung per Tastatur UND Touch, Anpassung an die Fenstergröße. "+
 "Schwierigkeit langsam steigern. Für Animationen/Videos: flüssige Animation per requestAnimationFrame und ein Knopf 'Als Video aufnehmen', "+
 "der canvas.captureStream(30) mit MediaRecorder (video/webm) für einige Sekunden aufnimmt und als .webm-Datei herunterlädt. Große Projekte erst als funktionierende Grundversion bauen und testen, dann erweitern.\n"+
 "Programme (Python, Node, Bots, Tools, Web-Apps mit Flask/Gradio/Express): lege sie in einem Projektordner an (mit requirements.txt bzw. package.json), "+
 "installiere mit setup_project, starte mit start_app (z.B. 'python app.py', 'npm start') und lies die Ausgabe. Bei Fehlern (Traceback, Exit-Code ungleich 0): Ursache in der Ausgabe suchen, Code mit edit_file reparieren, erneut starten – bis es läuft. "+
 "Tests mit start_app und 'python -m pytest -q' (wait 30). Web-Apps müssen auf 127.0.0.1 mit festem Port lauschen und die Adresse ausgeben; der Nutzer sieht sie dann automatisch. Lang laufende Programme am Ende laufen lassen, Testläufe mit stop_app beenden.\n"+
 "Open Source nutzen (für große Projekte): Statt alles neu zu schreiben, suche passende Projekte mit github_search (oder hf_search für KI-Apps/Modelle), "+
 "prüfe mit github_read/hf_read README, Dateien und LIZENZ, und hole ein gutes Projekt mit github_download/hf_download. Danach im neuen Ordner mit list_dir/read_file verstehen und mit edit_file/write_file an den Wunsch des Nutzers anpassen. "+
 "LIZENZREGELN: Nur Code mit freier Open-Source-Lizenz (z.B. MIT, Apache-2.0, BSD, GPL, MPL) verwenden. Code ohne Lizenz NIE kopieren, auch nicht abschreiben. "+
 "LICENSE-Datei und QUELLEN.md nie löschen. Wenn du einzelne Dateien/Code-Stücke aus anderen Projekten übernimmst, trage Quelle und Lizenz in QUELLEN.md des Projekts ein. "+
 "Bei GPL/AGPL den Nutzer darauf hinweisen, dass sein Projekt dann ebenfalls unter dieser Lizenz stehen muss, wenn er es weitergibt. Nenne dem Nutzer am Ende, welche Projekte du verwendet hast.\n"+
 "Design: modern und hochwertig - klares Farbschema mit CSS-Variablen, gute Typografie (system-ui), großzügige Abstände, Karten mit abgerundeten Ecken und sanften Schatten, "+
 "Hover-Effekte, responsiv per Flexbox/Grid und Media Queries, sinnvolle echte Beispieltexte statt Lorem ipsum, Navigation, Hero-Bereich, Footer. Bilder als CSS-Verläufe oder Emoji, keine fehlenden Bilddateien.\n"+
 "WICHTIG: Zeige NIEMALS Code im Chat. Code gehört ausschließlich mit write_file in Dateien. Wenn der Nutzer 'bau mir', 'erstelle' oder 'mach mir' sagt, fängst du sofort mit update_plan und write_file an, ohne Rückfragen.\n"+
 "Keine zerstörerischen Befehle (Löschen, Formatieren, Systemeinstellungen), außer der Nutzer verlangt es ausdrücklich. Antworte in der Sprache des Nutzers (Deutsch oder Englisch)."}
const NUDGE="Du hast Code im Chat gezeigt, statt ihn zu speichern. Zeige keinen Code. Speichere jetzt jede Datei mit write_file im Projektordner (z.B. projektname/index.html, projektname/style.css, projektname/script.js) und rufe danach show_preview auf.";
const NOTOOLS_SYSTEM="Du kannst keine Werkzeuge benutzen. Gib deshalb jede Datei vollständig als eigenen Code-Block aus. Schreibe direkt vor jeden Code-Block den Dateinamen in einer eigenen Zeile, z.B. **index.html**. Keine Platzhalter, keine Auslassungen.";
const BUILD_RE_EN=/\b(build|create|make|code|develop|write|design)\b[\s\S]*\b(web|website|site|page|homepage|landing|app|game|tool|program|calculator|form|shop|store|portfolio|dashboard|3d|animation|video|scene|simulation|visuali[sz]ation)/i;
const BUILD_RE=/\b(bau|baue|erstell|erstelle|mach|programmier|programmiere|entwickel|entwickle|schreib|schreibe)\b[\s\S]*\b(web|webseite|website|seite|homepage|landingpage|app|spiel|game|3d|animation|animiert|video|szene|simulation|visualisierung|tool|programm|rechner|formular|shop|portfolio)/i;
const MAX_STEPS=25;

/* Identität der App */
const BRAND="Sulaiman Durrani Open Source KI-Agent";
function identity(){return "Du bist der „"+BRAND+"“, entwickelt von Sulaiman Durrani. Wenn jemand fragt, wer oder was du bist, wie du heißt oder wer dich programmiert/entwickelt hat, "+
  "antworte: Ich bin der "+BRAND+", entwickelt von Sulaiman Durrani. Nur wenn ausdrücklich nach dem zugrunde liegenden Sprachmodell gefragt wird, sag ehrlich, dass im Hintergrund das Open-Source-/Ollama-Modell „"+
  ($("model").value||"unbekannt")+"“ läuft. Erfinde keine weiteren Angaben über deine Herkunft."}
/* Verlauf für das Modell: Projektwissen dazu, Ballast raus, damit der Kontext reicht */
const projInfoCache={};
async function refreshProjectInfo(c){
  const pr=settings.agent&&findProject(c);if(!pr){delete projInfoCache[c.id];return}
  try{projInfoCache[c.id]=await (await fetch("/__project_info?path="+encodeURIComponent(pr))).json()}catch(e){}}
const shortArgs=a=>{const o={};for(const k in a||{}){const v=a[k];o[k]=typeof v==="string"&&v.length>300?"[… "+v.length+" Zeichen, bereits ausgeführt – bei Bedarf mit read_file lesen]":v}return o};
const cut=(t,n)=>t&&t.length>n?t.slice(0,n)+" …[gekürzt]":t;
function buildHistory(c){
  let h=[];
  const msgs=c.messages.filter(m=>!m.error&&m.role!=="summary"&&m.role!=="note");
  const KEEP_FULL=6;
  msgs.forEach((m,i)=>{
    const recent=i>=msgs.length-KEEP_FULL;
    if(m.role==="tool"){h.push({role:"tool",content:recent?m.content:cut(m.content,300),tool_name:m.tool_name});return}
    let content=m.role==="assistant"?splitThink(m.content||"").answer:m.content;
    if(!recent&&m.role==="assistant")content=cut(content,600);
    const x={role:m.role,content};
    if(m.images&&m.images.length&&(recent||i===msgs.length-1))x.images=m.images;
    if(m.tool_calls)x.tool_calls=m.tool_calls.map(tc=>({function:{name:tc.function.name,arguments:shortArgs(tc.function.arguments)}}));
    h.push(x)});
  const proj=settings.agent&&findProject(c);
  let projTxt="";
  if(proj){
    const info=projInfoCache[c.id]||{};
    projTxt="Aktuelles Projekt in diesem Chat: "+proj+". Änderungswünsche des Nutzers beziehen sich auf dieses Projekt: lies die betroffenen Dateien mit read_file, "+
    "setze die Änderung dann mit write_file (bei größeren Umbauten ganze Datei neu) oder edit_file vollständig um, danach check_preview und show_preview. "+
    "Eine Änderung ist erst fertig, wenn die Dateien wirklich geändert sind – nur lesen und dann aufhören ist falsch."+
    (info.tree?"\n\nDateien im Projekt:\n"+info.tree:"")+
    (info.notes?"\n\nProjekt-Notizen (AGENT.md – dein Gedächtnis für dieses Projekt):\n"+info.notes:"")+
    "\n\nWichtige Entscheidungen (Aufbau, Farben, Bibliotheken, offene Punkte) trägst du kurz in AGENT.md im Projektordner unter '## Aufbau & Entscheidungen' ein (edit_file oder write_file). Der Verlauf wird automatisch ergänzt."}
  const sys=[identity(),settings.agent?agentSystem():"",projTxt,settings.system.trim()].filter(Boolean).join("\n\n");
  // Kontext-Budget: grob 3 Zeichen pro Token, Platz für Werkzeuge und Antwort lassen
  const toolsLen=settings.agent?JSON.stringify(AGENT_TOOLS).length:0;
  const budget=Math.max(4000,Math.floor(ctxFor($("model").value)*3.2)-toolsLen-sys.length-3000);
  const size=x=>JSON.stringify(x).length;let total=h.reduce((s,x)=>s+size(x),0);const dropped=[];
  // Der aktuelle Auftrag (letzte echte Nutzer-Nachricht) und alles danach bleibt immer erhalten
  const realUsers=msgs.map((m,i)=>m.role==="user"&&!m.hidden?i:-1).filter(i=>i>=0);
  let anchor=realUsers.length?realUsers[realUsers.length-1]:0;
  while(total>budget&&anchor>0){const x=h.shift();anchor--;total-=size(x);if(x.role==="user"&&!/^Du hast |^Automatischer Test/.test(x.content||""))dropped.push(cut(x.content||"",120))}
  while(anchor>0&&h.length>1&&h[0].role!=="user"){total-=size(h.shift());anchor--}
  if(total>budget){ // innerhalb des laufenden Auftrags: große, schon verarbeitete Ergebnisse stutzen (die letzten 2 bleiben)
    for(let i=anchor+1;i<h.length-2&&total>budget;i++){const x=h[i];
      if(x.role==="tool"&&x.content&&x.content.length>800){total-=x.content.length;x.content=cut(x.content,800);total+=x.content.length}}}
  if(dropped.length)h.unshift({role:"system",content:"Ältere Teile dieses Chats wurden aus Platzgründen ausgeblendet. Frühere Aufträge des Nutzers"+(dropped.length>8?" (die letzten 8 von "+dropped.length+")":"")+": "+dropped.slice(-8).map(d=>"«"+d+"»").join("; ")+
    (proj?". Der aktuelle Stand steht in den Projektdateien und in AGENT.md.":"")});
  if(sys)h.unshift({role:"system",content:sys});
  return h;
}
function argText(name,a){a=a||{};
  if(name==="run_command")return a.command||"";
  if(name==="write_file")return (a.path||"")+"\n\n"+(a.content||"");
  if(name==="edit_file")return (a.path||"")+"\n\n- "+(a.find||"").split("\n").join("\n- ")+"\n+ "+(a.replace||"").split("\n").join("\n+ ");
  if(name==="fetch_url")return a.url||"";
  if(name==="start_app")return (a.path||"")+"  >  "+(a.command||"");
  if(name==="setup_project")return (a.path||"")+"  (requirements.txt / package.json)";
  if(name==="app_output"||name==="stop_app")return a.proc||"";
  if(name==="web_search"||name==="github_search"||name==="hf_search")return (a.query||"")+(a.kind?"  ("+a.kind+")":"");
  if(name==="github_read"||name==="github_download")return (a.repo||"")+(a.path?" / "+a.path:"")+(a.folder?"  →  Ordner "+a.folder:"");
  if(name==="hf_read"||name==="hf_download")return (a.repo_id||"")+"  ("+(a.kind||(name==="hf_download"?"spaces":"models"))+")"+(a.path?" / "+a.path:"")+(a.folder?"  →  Ordner "+a.folder:"");
  return a.path||a.target||JSON.stringify(a)}
let runState=null;
const VISION_PREF=["qwen3.5:4b","qwen2.5vl:3b","qwen2.5vl:7b","gemma3:4b","llama3.2-vision:latest","llava:latest","llava:7b","minicpm-v:latest","moondream:latest"];
async function visionCaps(n){try{const r=await fetch("/api/show",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:n})});
  const j=await r.json();return Array.isArray(j.capabilities)&&j.capabilities.includes("vision")}catch(e){return false}}
async function pickVisionModel(){
  const cur=$("model").value;if(cur&&(await visionCaps(cur))&&sizeOf(cur)<MAX_AGENT_SIZE)return cur;
  for(const n of VISION_PREF)if(models.some(m=>m.name===n)&&sizeOf(n)<MAX_AGENT_SIZE&&(await visionCaps(n)))return n;
  for(const m of models)if(m.size<MAX_AGENT_SIZE&&(await visionCaps(m.name)))return m.name;
  return null}
async function reviewWithVision(screens,c){
  const vm=await pickVisionModel();
  if(!vm)return "Screenshots erstellt, aber kein Bild-Modell installiert – Design konnte nicht begutachtet werden. (Tipp für den Nutzer: ollama pull qwen2.5vl:3b)";
  const prompt="Du bist ein strenger, erfahrener Webdesign-Prüfer. Bild 1 zeigt die Seite am Computer (1280px breit)"+(screens.length>1?", Bild 2 auf dem Handy (390px breit)":"")+". "+
    "Auftrag des Nutzers: «"+lastUserText(c)+"». Nenne konkret bis zu 6 SICHTBARE Probleme: Überlappungen, abgeschnittene oder überlaufende Inhalte, schlechte Lesbarkeit/Kontrast, "+
    "leere oder kaputte Bereiche, fehlende Dinge aus dem Auftrag, Probleme in der Handy-Ansicht, unschönes Design. Jeweils mit Vorschlag zur Behebung. "+
    "Wenn alles gut aussieht, antworte genau: Keine wesentlichen Probleme. Antworte kurz als Liste auf Deutsch.";
  try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},signal:ctrl&&ctrl.signal,
      body:JSON.stringify({model:vm,stream:false,keep_alive:KEEP,think:false,options:{num_ctx:4096,temperature:0.2},messages:[{role:"user",content:prompt,images:screens}]})});
    if(!r.ok){let t=await r.text();try{t=JSON.parse(t).error||t}catch(e){}
      if(/think/i.test(t)){const r2=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},signal:ctrl&&ctrl.signal,
          body:JSON.stringify({model:vm,stream:false,keep_alive:KEEP,options:{num_ctx:4096,temperature:0.2},messages:[{role:"user",content:prompt,images:screens}]})});
        if(r2.ok){const j2=await r2.json();return "Design-Prüfung durch Bild-Modell "+vm+":\n"+((j2.message&&j2.message.content)||"").trim()}}
      return "Design-Prüfung fehlgeschlagen ("+vm+"): "+t}
    const j=await r.json();return "Design-Prüfung durch Bild-Modell "+vm+":\n"+((j.message&&j.message.content)||"(keine Antwort)").trim()}
  catch(e){if(e.name==="AbortError")throw e;return "Design-Prüfung fehlgeschlagen: "+e.message}}
const CHANGE_RE=/(änder|aender|mach|füg|fueg|hinzu|soll|muss|ersetz|entfern|lösch|loesch|wechsel|tausch|option|button|knopf|farb|design|größ|groess|klein|schrift|hintergrund|verbesser|neu|zeig|add|change|make|remove|replace|update|fix|improve|color|colour|bigger|smaller|switch|toggle)/i;
const lastUserText=c=>{const u=[...c.messages].reverse().find(x=>x.role==="user"&&!x.hidden);return u?u.content||"":""};
function projectFromPath(p){
  if(!p||!INFO.projects)return null;const base=INFO.projects.replace(/[\\\/]+$/,"");
  if(p.toLowerCase().indexOf(base.toLowerCase())!==0)return null;
  const rest=p.slice(base.length).replace(/^[\\\/]+/,"");const first=rest.split(/[\\\/]/)[0];
  if(!first||first.startsWith(".")||first===rest)return null;
  return base+(base.includes("\\")?"\\":"/")+first}
function findProject(c){
  if(c.project)return c.project;
  for(const m of [...c.messages].reverse()){
    const cands=m.role==="summary"?(m.files||[]).map(f=>f.path):m.role==="tool"&&m.args?[m.args.path,m.args.target]:[];
    for(const p of cands){const pr=projectFromPath(p);if(pr){c.project=pr;return pr}}}
  return null}
function followText(c){return "Du hast die Änderung noch NICHT umgesetzt – es wurde keine Datei geändert. Auftrag des Nutzers: «"+lastUserText(c)+"». "+
  "Setze ihn JETZT vollständig um: ändere die Dateien"+(c.project?" in "+c.project:" im Projektordner")+" mit write_file (ganze Datei neu schreiben, wenn viel geändert wird) oder edit_file. "+
  "Nur lesen reicht nicht. Danach check_preview und show_preview."}
const QUESTION_RE=/^\s*(wie|was|warum|wieso|weshalb|wo|wann|wer|welche[rsmn]?|erklär|erklaer|gibt es|how|what|why|where|when|who|which|explain|do you|does it|is it|are you)\b/i;
const isQuestion=t=>QUESTION_RE.test(t||"")&&!/^\s*(wie wäre es|was wäre wenn)/i.test(t||"");
function isBuildRequest(c){const u=[...c.messages].reverse().find(x=>x.role==="user"&&!x.hidden);const t=u?u.content||"":"";
  if(isQuestion(t))return false;
  return BUILD_RE.test(t)||BUILD_RE_EN.test(t)||/\b(speicher|datei|projekt|save|file)\w*/i.test(t)}
function recordFile(path,kind,undo){const f=runState.files.get(path)||{kind,undo:[]};if(f.kind!=="neu")f.kind=kind;if(undo)f.undo.push(undo);runState.files.set(path,f)}
async function undoIds(ids){const r=await fetch("/__undo",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({ids:[...ids].reverse()})});
  let j={};try{j=await r.json()}catch(e){}return {ok:r.ok,done:new Set(j.done||[]),messages:j.messages||[]}}
function checkPreview(url){
  return new Promise(resolve=>{
    const f=document.createElement("iframe");f.setAttribute("sandbox","allow-scripts allow-forms");
    f.style.cssText="position:fixed;left:-2000px;top:0;width:1200px;height:800px;border:0";
    let rep=null,timer;
    const onMsg=e=>{if(e.source===f.contentWindow&&e.data&&e.data.__ollamaPreview)rep=e.data};
    const finish=()=>{window.removeEventListener("message",onMsg);f.remove();
      if(!rep){resolve("Seite hat nicht geladen oder keine Antwort geliefert (Zeitüberschreitung). Prüfe, ob die HTML-Datei gültig ist.");return}
      const i=rep.info||{},out=[];
      out.push("Seite geladen. Titel: "+(i.title?"\""+i.title+"\"":"(kein <title>)")+", "+i.text+" Zeichen Text, "+i.elements+" Elemente, "+i.images+" Bilder, "+i.links+" Links"+(i.canvases?", "+i.canvases+" Canvas (Zeichenfläche)":"")+".");
      if(i.width>i.viewport+5)out.push("Problem: Seite ist breiter als das Fenster ("+i.width+"px statt "+i.viewport+"px) – horizontales Scrollen.");
      if(!i.text&&!i.canvases)out.push("Problem: Die Seite zeigt keinen Text an.");
      const errs=[...new Set(rep.errors||[])];
      out.push(errs.length?errs.length+" Fehler:\n- "+errs.join("\n- "):"Keine JavaScript-Fehler, alle Dateien gefunden.");
      resolve(out.join("\n"))};
    window.addEventListener("message",onMsg);
    f.onload=()=>{setTimeout(()=>{try{f.contentWindow.postMessage("__ollamaReport","*")}catch(e){}
      clearTimeout(timer);timer=setTimeout(finish,500)},1200)};
    timer=setTimeout(finish,8000);
    f.src=url+(url.includes("?")?"&":"?")+"t="+Date.now();document.body.appendChild(f);
  })}
async function askPermission(call){
  const name=call.function.name,args=call.function.arguments||{};
  if(NO_ASK.has(name))return true;
  if(settings.autoRead&&READ_ONLY.has(name))return true;
  let chk=null;
  if(name==="write_file"||name==="edit_file"){try{chk=await (await fetch("/__check?path="+encodeURIComponent(args.path||""))).json()}catch(e){}
    if(chk&&chk.in_projects&&runState&&runState.allowProjects)return true}
  return new Promise(resolve=>{
    const card=document.createElement("div");card.className="approve";
    card.innerHTML='<div class="ah">Der Agent möchte: <b></b></div><pre class="ac"></pre><div class="ab"><button class="primary">Erlauben</button><button class="danger">Ablehnen</button></div>';
    card.querySelector("b").textContent=(TOOL_LABEL[name]||name)+(chk&&name==="write_file"?(chk.exists?" (überschreiben)":" (neu)"):"");
    card.querySelector(".ac").textContent=chk?(name==="edit_file"?argText(name,Object.assign({},args,{path:chk.path})):chk.path+"\n\n"+(args.content||"")):argText(name,args);
    const [yes,no]=card.querySelectorAll("button");
    const done=v=>{card.remove();pendingDeny=null;resolve(v)};
    yes.onclick=()=>done(true);no.onclick=()=>done(false);pendingDeny=()=>done(false);
    if(chk&&chk.in_projects){const all=document.createElement("button");all.textContent="Alle Dateien im Projektordner erlauben (dieser Auftrag)";
      all.onclick=()=>{if(runState)runState.allowProjects=true;done(true)};card.querySelector(".ab").appendChild(all)}
    $("inner").appendChild(card);$("log").scrollTop=$("log").scrollHeight;yes.focus();
  });
}
let pendingDeny=null;

/* Gleiche Optionen für Chat, Agent und Vorladen -> Ollama muss das Modell nie neu laden */
const DEFAULT_CTX=12288,CLOUD_CTX=32768,KEEP="60m";
const isCloud=n=>/[:-]cloud$/i.test(n||"");
function ctxFor(model){return settings.num_ctx?+settings.num_ctx:(isCloud(model)?CLOUD_CTX:DEFAULT_CTX)}
function baseOpts(model){const o={num_ctx:ctxFor(model||$("model").value)};if(settings.temperature!=null)o.temperature=settings.temperature;return o}
let noThinkSupport=new Set();
async function streamOnce(c,model,row,m,noTools){
  const opts=baseOpts(model);
  const body={model,messages:buildHistory(c).slice(0,-1),stream:true,options:opts,keep_alive:KEEP};
  if(!settings.think&&!noThinkSupport.has(model))body.think=false;
  if(settings.agent&&!noTools)body.tools=settings.designCheck===false?AGENT_TOOLS.filter(t=>t.function.name!=="review_design"):AGENT_TOOLS;
  if(noTools)body.messages.splice(body.messages[0]&&body.messages[0].role==="system"?1:0,0,{role:"system",content:NOTOOLS_SYSTEM});
  const log=$("log");let pending=false;
  const paint=()=>{if(pending)return;pending=true;requestAnimationFrame(()=>{pending=false;if(!row.isConnected)return;
    const near=log.scrollHeight-log.scrollTop-log.clientHeight<120;fillBot(row,m,true);if(near)log.scrollTop=log.scrollHeight})};
  let r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},signal:ctrl.signal,body:JSON.stringify(body)});
  if(!r.ok){let t=await r.text();try{t=JSON.parse(t).error||t}catch(e){}
    if("think" in body&&/think/i.test(t)){noThinkSupport.add(model);delete body.think;
      r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},signal:ctrl.signal,body:JSON.stringify(body)});
      if(!r.ok){t=await r.text();try{t=JSON.parse(t).error||t}catch(e){}throw new Error(t)}}
    else throw new Error(t)}
  await readLines(r,j=>{
    if(j.error)throw new Error(j.error);
    if(j.message){if(j.message.content)m.content+=j.message.content;if(j.message.thinking)m.thinking+=j.message.thinking;
      if(j.message.tool_calls&&j.message.tool_calls.length)m.tool_calls=(m.tool_calls||[]).concat(j.message.tool_calls);paint()}
    if(j.done&&j.eval_count&&j.eval_duration){const tps=j.eval_count/(j.eval_duration/1e9);
      m.stats=j.eval_count+" Tokens · "+tps.toFixed(1)+" Tokens/s"+(j.load_duration>2e9?" · Modell geladen in "+(j.load_duration/1e9).toFixed(0)+" s":"");lastTps=tps}
  });
  checkSpeed();
}
function hasCode(t){return /```[\s\S]*?\n[\s\S]+?```/.test(t||"")}
function slug(t){const um={"ä":"ae","ö":"oe","ü":"ue","Ä":"Ae","Ö":"Oe","Ü":"Ue","ß":"ss"};
  return ((t||"projekt").replace(/[äöüÄÖÜß]/g,x=>um[x]).toLowerCase().replace(/\b(bau|baue|mir|mach|erstelle?|bitte|eine?n?|fuer|für|die|der|das|programmiere?)\b/g," ")
    .replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,30)||"projekt")}
function extractFiles(text){
  const files=[];const re=/```([^\n`]*)\n([\s\S]*?)```/g;let mm,last=0,n=0;const used=new Set();
  const byLang={html:"index.html",htm:"index.html",css:"style.css",js:"script.js",javascript:"script.js",python:"main.py",py:"main.py",json:"data.json"};
  while((mm=re.exec(text))){
    const before=text.slice(last,mm.index).split("\n").slice(-3).join("\n");last=re.lastIndex;
    const fm=before.match(/([\w\-\/]+\.(?:html?|css|js|py|json|md|txt|svg))(?![\s\S]*[\w\-\/]+\.(?:html?|css|js|py|json|md|txt|svg))/i);
    const lang=(mm[1]||"").trim().toLowerCase().split(/\s+/)[0];let name=fm?fm[1]:(byLang[lang]||null);
    const code=mm[2].replace(/\s+$/,"")+"\n";
    if(!name){if(/<html|<!doctype/i.test(code))name="index.html";else{n++;name="datei"+n+".txt"}}
    if(used.has(name)){const i=name.lastIndexOf(".");name=name.slice(0,i)+"-"+files.length+name.slice(i)}
    used.add(name);files.push({name,code})}
  return files}
async function saveCodeFallback(c,m){
  const files=extractFiles(splitThink(m.content).answer);if(!files.length)return;
  const userMsg=[...c.messages].reverse().find(x=>x.role==="user"&&!x.hidden);
  const d=new Date(),folder=slug(userMsg&&userMsg.content)+"-"+String(d.getHours()).padStart(2,"0")+String(d.getMinutes()).padStart(2,"0");
  const note={role:"note",content:"Das Modell hat den Code nur angezeigt – er wird jetzt automatisch als "+files.length+" Datei(en) in "+INFO.projects+"\\"+folder+" gespeichert."};
  c.messages.push(note);$("inner").appendChild(msgNode(note,false));
  for(const f of files){
    const call={function:{name:"write_file",arguments:{path:folder+"/"+f.name,content:f.code}}};
    const ok=await askPermission(call);if(ctrl&&ctrl.signal.aborted)return;
    let result="Der Nutzer hat diese Aktion abgelehnt.",extra={};
    if(ok){const tr=await fetch("/__tool",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"write_file",arguments:call.function.arguments})});
      if(tr.ok){extra=await tr.json();result=extra.result}
      if(extra.path&&/^(Erstellt|Überschrieben)/.test(result))recordFile(extra.path,result.startsWith("Erstellt")?"neu":"geändert",extra.undo)}
    const tm={role:"tool",tool_name:"write_file",args:call.function.arguments,content:result,denied:!ok};c.messages.push(tm);
    $("inner").appendChild(msgNode(tm,false));$("log").scrollTop=$("log").scrollHeight;save()}
  const html=files.find(f=>/\.html?$/i.test(f.name));
  if(html&&runState.files.size){const tr=await fetch("/__tool",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({name:"show_preview",arguments:{path:folder+"/"+html.name}})});
    if(tr.ok){const j=await tr.json();if(j.preview)runState.preview=j.preview}}
}
async function run(){
  const c=chat(),model=$("model").value;
  if(!model){alert("Bitte zuerst ein Modell auswählen oder über „Modelle“ herunterladen.");return}
  ctrl=new AbortController();busy(true);
  const proj0=findProject(c);
  let m=null;runState={allowProjects:false,files:new Map(),preview:null,nudges:0,noTools:false,build:isBuildRequest(c),
    change:settings.agent&&!isQuestion(lastUserText(c))&&(isBuildRequest(c)||(!!proj0&&CHANGE_RE.test(lastUserText(c)))),followups:0,autoChecks:0,dirty:false};
  try{
    for(let step=0;step<MAX_STEPS;step++){
      m={role:"assistant",content:"",thinking:"",model};c.messages.push(m);
      const row=msgNode(m,true);$("inner").appendChild(row);$("log").scrollTop=$("log").scrollHeight;
      await refreshProjectInfo(c);
      try{await streamOnce(c,model,row,m,runState.noTools)}
      catch(e){if(settings.agent&&!runState.noTools&&/does not support tools/i.test(e.message||"")){
          runState.noTools=true;m.content="";m.thinking="";m.tool_calls=null;
          c.messages.splice(c.messages.indexOf(m),0,{role:"note",content:"Dieses Modell kann keine Werkzeuge benutzen – der Code wird aus der Antwort übernommen und automatisch als Dateien gespeichert."});
          renderMessages();const r2=msgNode(m,true);$("inner").appendChild(r2);await streamOnce(c,model,r2,m,true)}
        else throw e}
      if(settings.agent&&runState.build&&!runState.noTools&&(!m.tool_calls||!m.tool_calls.length)&&hasCode(m.content)&&!runState.files.size&&runState.nudges<2){
        runState.nudges++;fillBot(row,m,false);
        c.messages.push({role:"user",content:NUDGE,hidden:true});
        c.messages.push({role:"note",content:"\u21BB Agent erinnert: Code nicht zeigen, sondern selbst als Dateien speichern ("+runState.nudges+"/2)"});
        $("inner").appendChild(msgNode(c.messages[c.messages.length-1],false));save();continue}
      if(settings.agent&&!runState.noTools&&(!m.tool_calls||!m.tool_calls.length)){
        const empty=!splitThink(m.content||"").answer.trim();
        if(runState.change&&!runState.files.size&&runState.followups<2){
          runState.followups++;
          if(empty){c.messages.splice(c.messages.indexOf(m),1);row.remove()}else fillBot(row,m,false);
          c.messages.push({role:"user",content:followText(c),hidden:true});
          const nt={role:"note",content:"\u21BB Änderung wurde noch nicht umgesetzt – Agent wird angewiesen, sie jetzt wirklich auszuführen ("+runState.followups+"/2)"};
          c.messages.push(nt);$("inner").appendChild(msgNode(nt,false));save();continue}
        if(runState.dirty&&runState.autoChecks<2&&findProject(c)){
          const url=previewUrlFor(c.project+"/index.html");
          if(url){runState.autoChecks++;runState.dirty=false;
            const res=await checkPreview(url);
            const tm={role:"tool",tool_name:"check_preview",args:{path:"index.html (automatischer Test)"},content:res};
            c.messages.push(tm);$("inner").appendChild(msgNode(tm,false));
            if(!runState.preview)runState.preview=url;
            if(/\d+ Fehler:|Problem:/.test(res)){
              if(empty){c.messages.splice(c.messages.indexOf(m),1);row.remove()}else fillBot(row,m,false);
              c.messages.push({role:"user",hidden:true,content:"Automatischer Test nach deinen Änderungen hat Probleme gefunden:\n"+res+"\nBehebe sie jetzt mit edit_file oder write_file."});
              save();continue}}}
        if(empty&&runState.files.size){c.messages.splice(c.messages.indexOf(m),1);row.remove();m=null;break}
      }
      if(!settings.agent||!m.tool_calls||!m.tool_calls.length)break;
      fillBot(row,m,false);save();
      for(const call of m.tool_calls){
        const name=call.function&&call.function.name;let args=call.function&&call.function.arguments;
        if(typeof args==="string"){try{args=JSON.parse(args)}catch(e){args={}}call.function.arguments=args}
        const ok=await askPermission(call);
        if(ctrl.signal.aborted)throw new DOMException("abgebrochen","AbortError");
        let result;
        if(!ok)result="Der Nutzer hat diese Aktion abgelehnt. Frag nach oder schlage etwas anderes vor.";
        let extra={};
        if(ok){const tr=await fetch("/__tool",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,arguments:args})});
          if(tr.ok){extra=await tr.json();result=extra.result}else result="Fehler beim Ausführen (HTTP "+tr.status+")";
          if(extra.screens){runState.reviews=(runState.reviews||0)+1;
            result=settings.designCheck===false?"Design-Prüfung ist vom Nutzer ausgeschaltet.":runState.reviews>2?"Design wurde in diesem Auftrag schon zweimal geprüft – jetzt abschließen.":(result+"\n\n"+await reviewWithVision(extra.screens,c))}
          if(extra.check){result=await checkPreview(extra.check);runState.checks=(runState.checks||0)+1;runState.dirty=false}
          if(name==="write_file"&&extra.path&&/^(Erstellt|Überschrieben)/.test(result))recordFile(extra.path,result.startsWith("Erstellt")?"neu":"geändert",extra.undo);
          if(name==="edit_file"&&extra.path&&/^Geändert/.test(result))recordFile(extra.path,"geändert",extra.undo);
          if((name==="write_file"||name==="edit_file")&&extra.path&&/^(Erstellt|Überschrieben|Geändert)/.test(result)){if(/\.(html?|css|m?js)$/i.test(extra.path))runState.dirty=true;
            const pr=projectFromPath(extra.path);if(pr&&!c.project)c.project=pr}
          if(extra.folder){runState.files.set(extra.folder,{kind:"heruntergeladen (Ordner, mit Quellenangabe)",undo:[]});if(!c.project)c.project=extra.folder}
          if(extra.app_url){runState.preview=extra.app_url;runState.appPreview=true}
          if(extra.preview)runState.preview=extra.preview}
        const tm={role:"tool",tool_name:name,args,content:result,denied:!ok};
        if(extra.plan)tm.plan=extra.plan;if(extra.preview)tm.preview=extra.preview;if(extra.app_url)tm.app_url=extra.app_url;if(extra.screen_urls)tm.screens=extra.screen_urls;c.messages.push(tm);
        $("inner").appendChild(msgNode(tm,false));$("log").scrollTop=$("log").scrollHeight;save();
      }
      if(step===MAX_STEPS-1)c.messages.push({role:"assistant",model,content:"Ich habe nach "+MAX_STEPS+" Schritten angehalten. Schreib „weiter“, wenn ich fortfahren soll."});
    }
    if(settings.agent&&runState.build&&m&&!m.error&&!runState.files.size&&hasCode(m.content))await saveCodeFallback(c,m);
  }catch(e){
    if(e.name==="AbortError"){if(m)m.stats="gestoppt"}
    else if(m){m.error=(e.message||String(e)).trim();
      if(/not found/i.test(m.error))m.error+=" – Modell über „Modelle“ herunterladen.";
      if(/does not support tools/i.test(m.error))m.error+=" – Dieses Modell kann keine Werkzeuge benutzen. Für den Agent-Modus z.B. qwen3, qwen2.5 oder llama3.1 nehmen."}
  }finally{
    if(pendingDeny)pendingDeny();
    if(runState&&runState.files.size&&!runState.preview){
      const pr=findProject(c)||projectFromPath([...runState.files.keys()][0]);
      const edited=[...runState.files.values()].some(f=>f.undo&&f.undo.length);
      const web=[...runState.files.keys()].some(f=>/\.(html?|css|m?js)$/i.test(f));
      const html=[...runState.files.keys()].find(f=>/index\.html?$/i.test(f))||(pr&&edited&&web?pr+"/index.html":null);
      if(html)runState.preview=previewUrlFor(html)}
    if(runState&&runState.files.size&&findProject(c)&&!(m&&m.stats==="gestoppt")){
      const req=lastUserText(c),proj=c.project;
      fetch("/__notes",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({project:proj,request:req,
        files:[...runState.files.keys()].map(f=>f.split(/[\\\/]/).pop())})}).catch(()=>{})
        .then(()=>fetch("/__git_commit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({project:proj,message:"Agent: "+req})})).catch(()=>{})}
    if(runState&&runState.files.size){
      c.messages.push({role:"summary",files:[...runState.files].map(([path,f])=>({path,kind:f.kind,undo:f.undo})),preview:runState.preview,app:!!runState.appPreview,stopped:!!(m&&m.stats==="gestoppt")})}
    runState=null;
    ctrl=null;busy(false);c.updated=Date.now();
    if(m&&!m.content&&!m.thinking&&!m.error&&!m.tool_calls&&m.stats==="gestoppt")c.messages.splice(c.messages.indexOf(m),1);
    save();renderAll();$("t").focus();
  }
}
/* Agent braucht ein Modell, das Werkzeuge kann und in den Speicher passt */
const AGENT_PREF=["qwen2.5-coder:7b","qwen2.5-coder:latest","qwen3.5:4b","qwen3:8b","qwen2.5:7b","qwen3:4b","llama3.1:8b","llama3.1:latest","mistral:latest","qwen2:latest","qwen2.5-coder:1.5b"];
const MAX_AGENT_SIZE=10e9,capsCache={};
async function modelCaps(name){
  if(capsCache[name])return capsCache[name];
  try{const r=await fetch("/api/show",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:name})});
    const j=await r.json();const c=j.capabilities;
    capsCache[name]={tools:Array.isArray(c)?c.includes("tools"):((j.template||"").includes(".Tools")?true:null)}}
  catch(e){capsCache[name]={tools:null}}
  return capsCache[name]}
const sizeOf=n=>{const m=models.find(x=>x.name===n);return m&&m.size||0};
async function pickAgentModel(){
  const cur=$("model").value,c=await modelCaps(cur),big=sizeOf(cur)>MAX_AGENT_SIZE;
  if(c.tools!==false&&!big)return null;
  for(const n of AGENT_PREF){if(n===cur||!models.some(m=>m.name===n)||sizeOf(n)>MAX_AGENT_SIZE)continue;
    if((await modelCaps(n)).tools)return {name:n,why:big?cur+" ist mit "+gb(sizeOf(cur))+" zu groß für den Grafikspeicher (stürzt ab oder ist sehr langsam)":cur+" kann keine Werkzeuge benutzen"}}
  return null}
let sending=false;
async function send(){if(sending)return;sending=true;try{await sendInner()}finally{sending=false}}
async function sendInner(){
  const text=$("t").value.trim();if((!text&&!pendingImgs.length)||ctrl)return;
  if(!$("model").value){alert("Bitte zuerst ein Modell auswählen oder über „Modelle“ herunterladen.");return}
  if(!settings.agent&&(BUILD_RE.test(text)||BUILD_RE_EN.test(text))){settings.agent=true;store.set("oc_settings",settings);showAgent()}
  let switched=null;
  if(settings.agent){$("send").disabled=true;try{switched=await pickAgentModel()}finally{$("send").disabled=false}
    if(switched){$("model").value=switched.name;store.set("oc_model",switched.name);lastTps=null}}
  let c=chat();
  if(!c){c={id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),title:"",messages:[],updated:Date.now()};chats.push(c);current=c.id}
  if(!c.title)c.title=(text||"Bild").replace(/\s+/g," ").slice(0,40);
  const msg={role:"user",content:text};if(pendingImgs.length)msg.images=pendingImgs.splice(0);
  c.messages.push(msg);c.updated=Date.now();
  if(switched)c.messages.push({role:"note",content:"Agent nutzt jetzt "+switched.name+", weil "+switched.why+". (Oben im Menü kannst du jederzeit ein anderes Modell wählen.)"});
  $("t").value="";grow();renderAttach();save();renderAll();run();
}

/* ---------- Bilder (für Bild-Modelle) ---------- */
let pendingImgs=[];
function shrink(file){return new Promise((res,rej)=>{
  const r=new FileReader();r.onerror=rej;r.onload=()=>{const img=new Image();img.onerror=()=>rej(new Error("kein Bild"));
    img.onload=()=>{const max=1280,s=Math.min(1,max/Math.max(img.width,img.height));
      const cv=document.createElement("canvas");cv.width=Math.round(img.width*s);cv.height=Math.round(img.height*s);
      const g=cv.getContext("2d");g.fillStyle="#fff";g.fillRect(0,0,cv.width,cv.height);g.drawImage(img,0,0,cv.width,cv.height);
      res(cv.toDataURL("image/jpeg",0.85).split(",")[1])};img.src=r.result};r.readAsDataURL(file)})}
async function addFiles(files){
  for(const f of files){if(!f.type.startsWith("image/"))continue;if(pendingImgs.length>=4)break;
    try{pendingImgs.push(await shrink(f))}catch(e){}}
  renderAttach();
}
function renderAttach(){const a=$("attach");a.innerHTML="";
  pendingImgs.forEach((src,i)=>{const d=document.createElement("div");d.className="th";
    d.innerHTML='<img alt="Anhang"><button title="Entfernen">&#10005;</button>';d.querySelector("img").src="data:image/jpeg;base64,"+src;
    d.querySelector("button").onclick=()=>{pendingImgs.splice(i,1);renderAttach()};a.appendChild(d)})}
$("clip").onclick=()=>$("file").click();
$("file").onchange=e=>{addFiles([...e.target.files]);e.target.value=""};
$("t").addEventListener("paste",e=>{const f=[...(e.clipboardData?.files||[])].filter(x=>x.type.startsWith("image/"));if(f.length){e.preventDefault();addFiles(f)}});
const box=$("box");
["dragenter","dragover"].forEach(ev=>box.addEventListener(ev,e=>{e.preventDefault();box.classList.add("drop")}));
["dragleave","drop"].forEach(ev=>box.addEventListener(ev,e=>{e.preventDefault();box.classList.remove("drop")}));
box.addEventListener("drop",e=>addFiles([...e.dataTransfer.files]));
$("viewer").onclick=()=>$("viewer").close();

/* ---------- Projekte ---------- */
function showTab(p){$("tabProj").classList.toggle("on",p);$("tabChats").classList.toggle("on",!p);
  $("chats").hidden=p;$("search").hidden=p;$("projects").hidden=!p;if(p)loadProjects()}
$("tabChats").onclick=()=>showTab(false);$("tabProj").onclick=()=>showTab(true);
async function loadProjects(){
  const box=$("projects");box.innerHTML='<div class="help" style="padding:8px">lade…</div>';
  let j;try{j=await (await fetch("/__projects")).json()}catch(e){box.innerHTML='<div class="help" style="padding:8px">Fehler beim Laden.</div>';return}
  box.innerHTML="";
  try{const apps=(await (await fetch("/__apps")).json()).filter(a=>a.running);
    if(apps.length){const h=document.createElement("div");h.className="proj running";h.innerHTML="<div class='pn'>Laufende Programme</div>";
      apps.forEach(a=>{const r=document.createElement("div");r.className="pm";r.textContent=a.id+": "+a.project+" > "+a.cmd+" ";
        const sb=document.createElement("button");sb.textContent="Stopp";sb.className="danger";sb.style.cssText="padding:0 8px;font-size:12px";
        sb.onclick=async()=>{await fetch("/__stop_app",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:a.id})});loadProjects()};
        r.appendChild(sb);h.appendChild(r)});box.appendChild(h)}}catch(e){}
  if(!j.projects.length){box.innerHTML='<div class="help" style="padding:8px">Noch keine Projekte. Sag z.B. „Bau mir eine Webseite für …“.</div>';return}
  j.projects.forEach(pr=>{
    const d=document.createElement("div");d.className="proj";
    d.innerHTML="<div class='pn'></div><div class='pm'></div><div class='pb'></div>";
    d.querySelector(".pn").textContent=pr.name;
    d.querySelector(".pm").textContent=pr.files+(pr.files===1?" Datei":" Dateien")+" · "+new Date(pr.mtime*1000).toLocaleString("de-DE",{dateStyle:"short",timeStyle:"short"});
    const pb=d.querySelector(".pb");
    const btn=(t,title,fn)=>{const b=document.createElement("button");b.textContent=t;b.title=title;b.onclick=fn;pb.appendChild(b);return b};
    if(pr.index&&j.preview_port)btn("Ansehen","Im Browser öffnen",()=>window.open("http://localhost:"+j.preview_port+"/"+encodeURIComponent(pr.name)+"/index.html","_blank"));
    btn("Ordner","Im Explorer öffnen",()=>fetch("/__open_project",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:pr.name})}));
    btn("Versionen","Frühere Stände ansehen und wiederherstellen",()=>showVersions(pr.name));
    if(pr.index)btn("Veröffentlichen","Als Webseite im Internet veröffentlichen (GitHub Pages)",()=>publish(pr.name));
    btn("ZIP","Als ZIP-Datei herunterladen",()=>{const a=document.createElement("a");a.href="/__zip?name="+encodeURIComponent(pr.name);a.download="";document.body.appendChild(a);a.click();a.remove()});
    btn("Weiterarbeiten","Mit dem Agent an diesem Projekt weiterarbeiten",()=>{
      if(ctrl)return;current=null;save();renderAll();settings.agent=true;store.set("oc_settings",settings);showAgent();showTab(false);
      $("t").value="Arbeite weiter am Projekt \""+pr.name+"\" (Ordner "+pr.path+"). Lies zuerst die vorhandenen Dateien. Änderung: ";
      grow();$("t").focus();$("t").setSelectionRange($("t").value.length,$("t").value.length);document.body.classList.remove("open")});
    box.appendChild(d)});
}

async function showVersions(name){
  const dlg=$("dlgVersions"),box=$("vlist");$("vtitle").textContent="Versionen: "+name;box.innerHTML='<div class="help">lade…</div>';dlg.showModal();
  let j;try{j=await (await fetch("/__versions?name="+encodeURIComponent(name))).json()}catch(e){box.innerHTML="Fehler beim Laden.";return}
  if(!j.git){box.innerHTML='<div class="help">Git ist nicht installiert. Öffne die Eingabeaufforderung und gib ein:<br><code>winget install Git.Git</code><br>Danach den Launcher neu starten. Ab dann wird nach jedem Auftrag automatisch eine Version gespeichert.</div>';return}
  if(!j.versions.length){box.innerHTML='<div class="help">Noch keine Versionen. Nach dem nächsten Auftrag des Agenten wird automatisch eine gespeichert.</div>';return}
  box.innerHTML="";j.versions.forEach((v,i)=>{const d=document.createElement("div");d.className="mitem";
    d.innerHTML="<span></span><small></small>";d.querySelector("span").textContent=v.msg;d.querySelector("small").textContent=v.date;
    if(i>0){const b=document.createElement("button");b.textContent="Wiederherstellen";b.onclick=async()=>{
      if(!confirm("Projekt auf diese Version zurücksetzen?\n\n„"+v.msg+"“ ("+v.date+")\n\nDer aktuelle Stand wird vorher gesichert und bleibt in der Liste."))return;
      b.disabled=true;const r=await fetch("/__restore",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,sha:v.sha})});
      const k=await r.json();if(r.ok)showVersions(name);else{alert("Fehler: "+k.error);b.disabled=false}};d.appendChild(b)}
    else{const t=document.createElement("small");t.textContent=" (aktuell)";d.appendChild(t)}
    box.appendChild(d)})}
async function publish(name){
  if(!confirm("„"+name+"“ veröffentlichen?\n\nDie Dateien werden ÖFFENTLICH auf GitHub hochgeladen und die Seite ist für jeden im Internet sichtbar. Keine privaten Daten oder Passwörter im Projekt lassen!"))return;
  const go=async()=>{const r=await fetch("/__publish",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})});const j=await r.json();
    if(r.ok){alert("Veröffentlicht!\n\nWebseite: "+j.url+"\nCode: "+j.repo+"\n\n"+j.uploaded+" Dateien hochgeladen, "+j.unchanged+" unverändert. "+j.note);window.open(j.url,"_blank");return}
    if(/Token/.test(j.error||"")){askToken(go);return}
    alert("Veröffentlichen fehlgeschlagen:\n"+j.error)};
  await go()}
function askToken(then){const d=$("dlgToken");$("tok").value="";d.showModal();
  $("tokSave").onclick=async()=>{const t=$("tok").value.trim();if(!t)return;
    await fetch("/__gh_token",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:t})});d.close();if(then)then()}}

/* ---------- Spracheingabe ---------- */
(function(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;const mic=$("mic");
  if(!SR){mic.hidden=true;return}
  let rec=null,base="";
  mic.onclick=()=>{
    if(rec){rec.stop();return}
    rec=new SR();rec.lang=settings.voiceLang||"de-DE";rec.interimResults=true;rec.continuous=true;
    base=$("t").value?$("t").value.replace(/\s*$/," "):"";
    rec.onresult=e=>{let txt="";for(let i=0;i<e.results.length;i++)txt+=e.results[i][0].transcript;$("t").value=base+txt;grow()};
    rec.onerror=e=>{if(e.error==="not-allowed")alert("Mikrofon-Zugriff wurde verweigert. Erlaube das Mikrofon in den Browser-Einstellungen für localhost.");
      else if(e.error==="network")alert("Spracherkennung braucht eine Internetverbindung (der Browser nutzt dafür einen Online-Dienst).")};
    rec.onend=()=>{rec=null;mic.classList.remove("rec");mic.title="Spracheingabe";$("t").focus()};
    try{rec.start();mic.classList.add("rec");mic.title="Aufnahme läuft – klicken zum Beenden"}catch(e){rec=null}
  };
})();
$("voiceLang").value=settings.voiceLang||"de-DE";
$("voiceLang").onchange=()=>{settings.voiceLang=$("voiceLang").value;store.set("oc_settings",settings)};

/* ---------- Suche, Export, Beenden ---------- */
$("search").oninput=renderList;
$("btnExport").onclick=()=>{const c=chat();if(!c||!c.messages.length){alert("Dieser Chat ist noch leer.");return}
  let out="# "+(c.title||"Chat")+"\n\n";
  c.messages.forEach(m=>{if(m.role==="summary"||m.role==="note"||m.hidden)return;if(m.role==="tool"){out+="> Aktion: "+(TOOL_LABEL[m.tool_name]||m.tool_name)+(m.denied?" (abgelehnt)":"")+"\n\n```\n"+String(m.content).slice(0,3000)+"\n```\n\n";return}
    if(m.role==="user")out+="## Du\n\n"+(m.images&&m.images.length?"_["+m.images.length+" Bild(er)]_\n\n":"")+m.content+"\n\n";
    else out+="## "+(m.model||"Modell")+"\n\n"+(m.error?"Fehler: "+m.error:splitThink(m.content).answer)+"\n\n"});
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([out],{type:"text/markdown"}));
  const um={"ä":"ae","ö":"oe","ü":"ue","Ä":"Ae","Ö":"Oe","Ü":"Ue","ß":"ss"};
  a.download=((c.title||"chat").replace(/[äöüÄÖÜß]/g,x=>um[x]).normalize("NFKD").replace(/[^\x20-\x7e]/g,"")
    .replace(/[\\/:*?"<>|]+/g,"_").trim().slice(0,50)||"chat")+".md";document.body.appendChild(a);a.click();
  setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)};
$("quit").onclick=async()=>{if(!confirm("Chat-Server beenden? Ollama selbst läuft weiter."))return;
  if(ctrl)ctrl.abort();try{await fetch("/__shutdown",{method:"POST"})}catch(e){}
  document.body.innerHTML='<div class="bye"><h2>Beendet</h2><p>Du kannst diesen Tab schließen.<br>Neu starten: Ollama_Start.bat bzw. „Sulaiman Durrani KI-Agent“ auf dem Desktop.</p></div>'};
function regenerate(){const c=chat();if(!c||ctrl)return;
  while(c.messages.length&&(c.messages[c.messages.length-1].role!=="user"||c.messages[c.messages.length-1].hidden))c.messages.pop();
  if(!c.messages.length)return;save();renderMessages();run()}
$("send").onclick=send;$("stop").onclick=()=>{if(ctrl)ctrl.abort();if(pendingDeny)pendingDeny()};
const grow=()=>{const t=$("t");t.style.height="auto";t.style.height=Math.min(t.scrollHeight,220)+"px"};
$("t").addEventListener("input",grow);
$("t").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey&&!e.isComposing){e.preventDefault();send()}});
$("newchat").onclick=()=>{current=null;save();renderAll();$("t").focus();document.body.classList.remove("open")};
$("menu").onclick=()=>document.body.classList.toggle("open");
$("main").addEventListener("click",e=>{if(!e.target.closest("#menu"))document.body.classList.remove("open")});

/* ---------- Einstellungen ---------- */
function showTemp(){$("tempv").textContent=settings.temperature==null?"Standard":settings.temperature.toFixed(2);$("temp").value=settings.temperature??0.8}
$("btnSettings").onclick=()=>{$("designCheck").checked=settings.designCheck!==false;$("think").checked=!!settings.think;$("autoRead").checked=!!settings.autoRead;$("sys").value=settings.system;$("ctx").value=settings.num_ctx||"";showTemp();$("dlgSettings").showModal()};
$("sys").oninput=()=>{settings.system=$("sys").value;store.set("oc_settings",settings)};
$("temp").oninput=()=>{settings.temperature=+$("temp").value;showTemp();store.set("oc_settings",settings)};
$("tempReset").onclick=()=>{settings.temperature=null;showTemp();store.set("oc_settings",settings)};
$("ctx").onchange=()=>{settings.num_ctx=$("ctx").value;store.set("oc_settings",settings);warmUp()};
$("designCheck").onchange=()=>{settings.designCheck=$("designCheck").checked;store.set("oc_settings",settings)};
$("think").onchange=()=>{settings.think=$("think").checked;store.set("oc_settings",settings)};
$("autoRead").onchange=()=>{settings.autoRead=$("autoRead").checked;store.set("oc_settings",settings)};
function showAgent(){$("agent").checked=!!settings.agent;document.body.classList.toggle("agent",!!settings.agent);
  $("t").placeholder=settings.agent?"Auftrag an den Agent, z.B. „Zeig mir die größten Dateien in Downloads“":"Nachricht an das Modell…"}
$("agent").onchange=()=>{settings.agent=$("agent").checked;store.set("oc_settings",settings);showAgent()};
showAgent();
$("btnModels").onclick=()=>{$("pullmsg").textContent="";loadModels();$("dlgModels").showModal()};

if(current&&!chat())current=null;
renderAll();loadModels();$("t").focus();
</script></body></html>"""


SERVER = None

# ------------------------------------------------------------------ Agent-Werkzeuge
# Werden NUR ausgeführt, nachdem du in der Oberfläche auf „Erlauben“ geklickt hast.
MAX_OUT = 8000
PROJECTS = os.path.join(os.path.expanduser("~"), "Ollama_Projekte")
PREVIEW_PORT = None


def _path(p, base=None):
    p = os.path.expandvars(os.path.expanduser(str(p or "").strip().strip('"')))
    if not p:
        return base or os.path.expanduser("~")
    if base and not os.path.isabs(p):
        p = os.path.join(base, p)
    return os.path.abspath(p)


def in_projects(p):
    try:
        return os.path.commonpath([os.path.normcase(PROJECTS), os.path.normcase(p)]) == os.path.normcase(PROJECTS)
    except ValueError:
        return False


def _cut(text):
    text = text or ""
    if len(text) > MAX_OUT:
        return text[:MAX_OUT] + f"\n…[gekürzt, {len(text) - MAX_OUT} Zeichen weggelassen]"
    return text


def tool_list_dir(path="~"):
    p = _path(path)
    rows = []
    for name in sorted(os.listdir(p), key=str.lower)[:300]:
        full = os.path.join(p, name)
        if os.path.isdir(full):
            rows.append(f"[Ordner] {name}")
        else:
            try:
                rows.append(f"{name}  ({os.path.getsize(full):,} Bytes)")
            except OSError:
                rows.append(name)
    return f"Inhalt von {p}:\n" + ("\n".join(rows) or "(leer)")


def tool_read_file(path):
    p = _path(path)
    with open(p, "rb") as f:
        data = f.read(200_000)
    for enc in ("utf-8", "cp1252"):
        try:
            return _cut(data.decode(enc))
        except UnicodeDecodeError:
            pass
    return "Keine Textdatei (Binärdaten)."


# ---- Backups / Rückgängig
BACKUPS = os.path.join(PROJECTS, ".backups")
JOURNAL = os.path.join(BACKUPS, "journal.json")
_jlock = threading.Lock()


def _journal():
    try:
        with open(JOURNAL, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save_journal(j):
    os.makedirs(BACKUPS, exist_ok=True)
    with open(JOURNAL, "w", encoding="utf-8") as f:
        json.dump(j[-500:], f, ensure_ascii=False)


def backup_before_change(p):
    """Sichert den aktuellen Stand einer Datei, bevor der Agent sie ändert."""
    os.makedirs(BACKUPS, exist_ok=True)
    uid = time.strftime("%Y%m%d-%H%M%S") + "-" + os.urandom(3).hex()
    entry = {"id": uid, "path": p, "time": time.time(), "backup": None}
    if os.path.isfile(p):
        dst = os.path.join(BACKUPS, uid + "_" + os.path.basename(p))
        shutil.copy2(p, dst)
        entry["backup"] = dst
    with _jlock:
        j = _journal()
        j.append(entry)
        _save_journal(j)
    return uid


def _fhash(p):
    import hashlib
    try:
        with open(p, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def finish_change(uid, p):
    """Merkt sich den Stand NACH der Änderung, damit Rückgängig später erkennt,
    ob die Datei inzwischen noch einmal verändert wurde."""
    with _jlock:
        j = _journal()
        for e in j:
            if e.get("id") == uid:
                e["after"] = _fhash(p)
        _save_journal(j)


def undo_change(uid):
    with _jlock:
        j = _journal()
        e = next((x for x in j if x.get("id") == uid), None)
        if not e:
            return False, "Sicherung nicht gefunden."
        if e.get("undone"):
            return True, "War schon rückgängig gemacht."
        if e.get("after") and _fhash(e["path"]) != e["after"]:
            return False, (f"Nicht rückgängig gemacht: {os.path.basename(e['path'])} wurde danach noch einmal "
                           "verändert (z.B. von dir oder einem späteren Auftrag). Mach zuerst den neueren Auftrag rückgängig.")
        if e.get("backup") and os.path.isfile(e["backup"]):
            os.makedirs(os.path.dirname(e["path"]), exist_ok=True)
            shutil.copy2(e["backup"], e["path"])
            msg = f"Wiederhergestellt: {e['path']}"
        elif not e.get("backup"):
            if os.path.isfile(e["path"]):
                os.remove(e["path"])
            msg = f"Entfernt (war neu): {e['path']}"
        else:
            return False, "Sicherungsdatei fehlt."
        e["undone"] = True
        _save_journal(j)
        return True, msg


def tool_write_file(path, content=""):
    p = _path(path, PROJECTS)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    existed = os.path.exists(p)
    uid = backup_before_change(p)
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    finish_change(uid, p)
    return {"result": f"{'Überschrieben' if existed else 'Erstellt'}: {p} ({len(content)} Zeichen)", "undo": uid}


def tool_run_command(command):
    if os.name == "nt":
        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
               "[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + command]
        flags = NO_WINDOW
    else:
        cmd, flags = ["bash", "-c", command], 0
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=120, cwd=os.path.expanduser("~"),
                           creationflags=flags)
    except subprocess.TimeoutExpired:
        return "Abgebrochen: Befehl lief länger als 120 Sekunden."
    out = (r.stdout or "") + (("\n[Fehlerausgabe]\n" + r.stderr) if r.stderr.strip() else "")
    return _cut(f"[Exit-Code {r.returncode}]\n{out.strip() or '(keine Ausgabe)'}")


def tool_open_item(target):
    t = str(target or "").strip()
    if t.startswith(("http://", "https://")):
        webbrowser.open(t)
        return f"Im Browser geöffnet: {t}"
    p = _path(t) if (os.sep in t or "/" in t or t.startswith("~")) else t
    if os.name == "nt":
        os.startfile(p)
    else:
        subprocess.Popen(["xdg-open", p], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return f"Geöffnet: {p}"


def tool_edit_file(path, find="", replace=""):
    p = _path(path, PROJECTS)
    with open(p, encoding="utf-8") as f:
        text = f.read()
    if not find:
        return "Parameter 'find' fehlt."
    n = text.count(find)
    if n == 0:
        return (f"Text nicht gefunden in {p}. Lies die Datei mit read_file und übernimm den zu ersetzenden "
                "Text exakt (inkl. Leerzeichen).")
    text = text.replace(find, replace, 1)
    uid = backup_before_change(p)
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    finish_change(uid, p)
    return {"result": f"Geändert: {p} (1 von {n} Stelle(n) ersetzt)", "undo": uid}


def tool_fetch_url(url):
    import html as _html
    import re
    if not str(url).startswith(("http://", "https://")):
        return "Nur http(s)-Adressen."
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (OllamaLauncher)"})
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read(1_500_000)
        ctype = r.headers.get("Content-Type", "")
        charset = r.headers.get_content_charset() or "utf-8"
    text = raw.decode(charset, errors="replace")
    if "html" in ctype or "<html" in text[:2000].lower():
        title = re.search(r"<title[^>]*>(.*?)</title>", text, re.S | re.I)
        text = re.sub(r"(?is)<(script|style|noscript|svg)[^>]*>.*?</\1>", " ", text)
        text = re.sub(r"(?i)<(br|p|div|li|h[1-6]|tr)[^>]*>", "\n", text)
        text = _html.unescape(re.sub(r"<[^>]+>", " ", text))
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n\s*\n+", "\n", text).strip()
        if title:
            text = "Titel: " + _html.unescape(title.group(1).strip()) + "\n\n" + text
    return _cut(text)


def parse_ddg(html_text, limit=8):
    import html as _html
    import re
    from urllib.parse import parse_qs, urlparse
    strip = lambda t: _html.unescape(re.sub(r"<[^>]+>", "", t or "")).strip()
    links = re.findall(r'<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', html_text, re.S)
    snippets = re.findall(r'class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</(?:a|td|div)>', html_text, re.S)
    out = []
    for i, (href, title) in enumerate(links):
        href = _html.unescape(href)
        if "uddg=" in href:
            q = parse_qs(urlparse(href if href.startswith("http") else "https:" + href).query)
            href = q.get("uddg", [href])[0]
        if "duckduckgo.com/y.js" in href:
            continue  # Werbung
        out.append(f"{len(out) + 1}. {strip(title)}\n   {href}\n   {strip(snippets[i]) if i < len(snippets) else ''}")
        if len(out) >= limit:
            break
    return out


def tool_web_search(query):
    from urllib.parse import quote
    q = str(query or "").strip()
    if not q:
        return "Suchbegriff fehlt."
    req = urllib.request.Request("https://html.duckduckgo.com/html/?q=" + quote(q),
                                 headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    with urllib.request.urlopen(req, timeout=20) as r:
        page = r.read(2_000_000).decode("utf-8", errors="replace")
    res = parse_ddg(page)
    if not res:
        return "Keine Ergebnisse gefunden (oder die Suche wurde blockiert). Versuche andere Begriffe oder fetch_url."
    return _cut(f"Suchergebnisse für \"{q}\":\n\n" + "\n".join(res) +
                "\n\nTipp: Mit fetch_url eine der Adressen öffnen, um Details zu lesen.")


# ---- Open Source: GitHub & Hugging Face
GITHUB_API = os.environ.get("OLLAMA_LAUNCHER_GITHUB_API", "https://api.github.com")
HF_BASE = os.environ.get("OLLAMA_LAUNCHER_HF", "https://huggingface.co")
OSS_LICENSES = {
    "mit", "apache-2.0", "bsd-2-clause", "bsd-3-clause", "bsd-3-clause-clear", "isc", "0bsd", "zlib",
    "unlicense", "cc0-1.0", "bsl-1.0", "mpl-2.0", "epl-1.0", "epl-2.0", "lgpl-2.1", "lgpl-3.0",
    "gpl-2.0", "gpl-3.0", "agpl-3.0", "wtfpl", "cc-by-4.0", "cc-by-sa-4.0", "openrail", "openrail++",
    "creativeml-openrail-m", "bigscience-openrail-m", "artistic-2.0", "ofl-1.1", "postgresql", "upl-1.0",
    "llama3", "llama3.1", "llama3.2", "gemma", "apple-ascl",
}
COPYLEFT = ("gpl", "agpl", "lgpl", "mpl", "epl", "cc-by-sa")
SKIP_EXT = (".safetensors", ".bin", ".gguf", ".pt", ".pth", ".ckpt", ".onnx", ".h5", ".msgpack",
            ".tflite", ".parquet", ".arrow", ".zip", ".tar", ".gz", ".7z", ".mp4", ".mov", ".wav")


def _get(url, accept="application/json", limit=5_000_000):
    headers = {"User-Agent": "OllamaLauncher/1.0", "Accept": accept}
    tok = gh_token()
    if tok and url.startswith(GITHUB_API):
        headers["Authorization"] = "Bearer " + tok
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.read(limit + 1)
    except urllib.error.HTTPError as e:
        if e.code == 403 and "api.github" in url or e.code == 429:
            raise RuntimeError("GitHub-Limit erreicht (ohne Anmeldung 60 Abfragen/Stunde, Suche 10/Minute). "
                               "Kurz warten oder einen GITHUB_TOKEN als Umgebungsvariable setzen.")
        if e.code == 404:
            raise RuntimeError("Nicht gefunden (404): " + url)
        raise RuntimeError(f"HTTP {e.code} bei {url}")


def _json(url):
    return json.loads(_get(url).decode("utf-8", "replace"))


def _repo_name(repo):
    r = str(repo or "").strip().rstrip("/")
    for pre in ("https://github.com/", "http://github.com/", "github.com/",
                "https://huggingface.co/", "huggingface.co/"):
        if r.lower().startswith(pre):
            r = r[len(pre):]
    parts = [p for p in r.split("/") if p]
    if parts and parts[0] in ("spaces", "datasets", "models"):
        parts = parts[1:]
    return "/".join(parts[:2])


def _license_ok(spdx):
    s = (spdx or "").lower()
    if s in OSS_LICENSES or s.startswith(("cc-by-", "llama")):
        return True, ("Copyleft-Lizenz (" + spdx + "): Wenn du dein Projekt weitergibst/veröffentlichst, "
                      "muss es unter derselben Lizenz stehen." if s.startswith(COPYLEFT) else "")
    return False, ""


def _safe_folder(name):
    name = "".join(ch if ch.isalnum() or ch in "-_." else "-" for ch in str(name or "")).strip("-.")
    return name[:60] or "projekt"


def _target_dir(folder, default):
    d = os.path.join(PROJECTS, _safe_folder(folder or default))
    if os.path.isdir(d) and os.listdir(d):
        raise RuntimeError(f"Ordner {d} existiert schon und ist nicht leer. Wähle mit 'folder' einen neuen Namen.")
    return d


def _note_source(d, lines):
    with open(os.path.join(d, "QUELLEN.md"), "a", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n\n")


def tool_github_search(query, sort="stars"):
    from urllib.parse import quote
    q = str(query or "").strip()
    if not q:
        return "Suchbegriff fehlt."
    data = _json(f"{GITHUB_API}/search/repositories?q={quote(q)}&sort={'updated' if sort == 'updated' else 'stars'}&order=desc&per_page=10")
    items = data.get("items") or []
    if not items:
        return f"Keine GitHub-Projekte gefunden für \"{q}\". Andere/englische Begriffe probieren."
    out = [f"GitHub-Projekte für \"{q}\" ({data.get('total_count', len(items))} Treffer, sortiert nach {'Aktualität' if sort == 'updated' else 'Sternen'}):"]
    for i, it in enumerate(items, 1):
        lic = (it.get("license") or {}).get("spdx_id") or "keine Lizenz"
        ok, _ = _license_ok(lic)
        out.append(f"{i}. {it.get('full_name')}  ★{it.get('stargazers_count', 0)}  [{it.get('language') or '-'}]  "
                   f"Lizenz: {lic}{'' if ok else ' (NICHT frei verwendbar)'}  {round((it.get('size') or 0) / 1024, 1)} MB\n"
                   f"   {(it.get('description') or '').strip()[:200]}\n   {it.get('html_url')}")
    out.append("\nMit github_read Details/README ansehen, mit github_download ein Projekt mit freier Lizenz holen.")
    return _cut("\n".join(out))


def tool_github_read(repo, path=""):
    import base64
    from urllib.parse import quote
    name = _repo_name(repo)
    if name.count("/") != 1:
        return "repo bitte als 'besitzer/projekt' angeben, z.B. mrdoob/three.js"
    path = str(path or "").strip("/")
    if not path:
        info = _json(f"{GITHUB_API}/repos/{name}")
        lic = (info.get("license") or {}).get("spdx_id") or "keine Lizenz"
        ok, warn = _license_ok(lic)
        files = _json(f"{GITHUB_API}/repos/{name}/contents?ref={quote(info.get('default_branch') or 'main')}")
        listing = "\n".join(("[Ordner] " if f.get("type") == "dir" else "") + f.get("name", "") for f in files[:150])
        readme = ""
        try:
            r = _json(f"{GITHUB_API}/repos/{name}/readme")
            readme = base64.b64decode(r.get("content", "")).decode("utf-8", "replace")[:6000]
        except Exception:
            readme = "(kein README)"
        return _cut(f"{info.get('full_name')}  ★{info.get('stargazers_count', 0)}  Sprache: {info.get('language')}\n"
                    f"Lizenz: {lic} -> {'frei verwendbar' if ok else 'NICHT frei verwendbar – nicht kopieren'}{(' – ' + warn) if warn else ''}\n"
                    f"Beschreibung: {info.get('description') or '-'}\nGröße: {round((info.get('size') or 0) / 1024, 1)} MB, "
                    f"Branch: {info.get('default_branch')}\n\nDateien:\n{listing}\n\nREADME:\n{readme}")
    data = _json(f"{GITHUB_API}/repos/{name}/contents/{quote(path)}")
    if isinstance(data, list):
        return f"Inhalt von {name}/{path}:\n" + "\n".join(
            ("[Ordner] " if f.get("type") == "dir" else "") + f.get("name", "") + (f"  ({f.get('size')} Bytes)" if f.get("type") == "file" else "")
            for f in data[:300])
    if data.get("encoding") == "base64" and data.get("content"):
        raw = base64.b64decode(data["content"])
    elif data.get("download_url"):
        raw = _get(data["download_url"], accept="*/*", limit=400_000)
    else:
        return "Datei konnte nicht gelesen werden."
    return _cut(raw.decode("utf-8", "replace"))


def tool_github_download(repo, folder=""):
    import io
    import zipfile
    name = _repo_name(repo)
    if name.count("/") != 1:
        return "repo bitte als 'besitzer/projekt' angeben."
    info = _json(f"{GITHUB_API}/repos/{name}")
    lic = (info.get("license") or {}).get("spdx_id") or ""
    ok, warn = _license_ok(lic)
    if not ok:
        why = ("hat keine Lizenz. Ohne Lizenz ist Code urheberrechtlich geschützt und darf nicht kopiert werden"
               if not lic or lic == "NOASSERTION" else f"hat die Lizenz {lic}, die nicht als freie Open-Source-Lizenz erkannt wird")
        return f"Abgelehnt: {name} {why}. Such ein anderes Projekt mit MIT, Apache-2.0, BSD, GPL o.ä."
    if (info.get("size") or 0) > 150_000:
        return f"Abgelehnt: {name} ist mit {round(info['size'] / 1024)} MB zu groß. Nimm einzelne Dateien mit github_read."
    d = _target_dir(folder, info.get("name") or name.split("/")[1])
    data = _get(f"{GITHUB_API}/repos/{name}/zipball/{info.get('default_branch') or ''}".rstrip("/"),
                accept="application/zip", limit=200_000_000)
    count, total = 0, 0
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for m in z.infolist():
            if m.is_dir():
                continue
            rel = m.filename.split("/", 1)[1] if "/" in m.filename else m.filename
            dst = os.path.abspath(os.path.join(d, rel))
            if not rel or not dst.startswith(os.path.abspath(d) + os.sep):
                continue  # Schutz vor Pfaden außerhalb des Zielordners
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with z.open(m) as src, open(dst, "wb") as out:
                shutil.copyfileobj(src, out)
            count += 1
            total += m.file_size
            if count >= 8000:
                break
    _note_source(d, [f"## {name}", f"- Quelle: https://github.com/{name}", f"- Lizenz: {lic}",
                     f"- Heruntergeladen: {time.strftime('%Y-%m-%d %H:%M')}",
                     "- Die Lizenzdatei des Originals muss erhalten bleiben."])
    return {"result": f"Heruntergeladen: {name} -> {d} ({count} Dateien, {round(total / 1e6, 1)} MB, Lizenz {lic}). "
                      f"Quellenangabe in QUELLEN.md.{(' Hinweis: ' + warn) if warn else ''} "
                      "Nächster Schritt: Struktur mit list_dir ansehen, README lesen, dann anpassen.",
            "folder": d}


def _hf_kind(kind):
    k = str(kind or "models").lower()
    return {"model": "models", "dataset": "datasets", "space": "spaces"}.get(k.rstrip("s"), k if k in ("models", "datasets", "spaces") else "models")


def _hf_license(info):
    lic = (info.get("cardData") or {}).get("license")
    if isinstance(lic, list):
        lic = lic[0] if lic else None
    if not lic:
        lic = next((t.split(":", 1)[1] for t in info.get("tags") or [] if t.startswith("license:")), None)
    return lic or ""


def _hf_url(kind, rid):
    return f"{HF_BASE}/{'' if kind == 'models' else kind + '/'}{rid}"


def tool_hf_search(query, kind="models"):
    from urllib.parse import quote
    kind = _hf_kind(kind)
    q = str(query or "").strip()
    sort = "likes" if kind == "spaces" else "downloads"
    items = _json(f"{HF_BASE}/api/{kind}?search={quote(q)}&sort={sort}&direction=-1&limit=10")
    if not items:
        return f"Keine Hugging-Face-{kind} gefunden für \"{q}\"."
    names = {"models": "Modelle", "datasets": "Datensätze", "spaces": "Spaces (Apps mit Quellcode)"}
    out = [f"Hugging Face {names[kind]} für \"{q}\":"]
    for i, it in enumerate(items, 1):
        lic = next((t.split(":", 1)[1] for t in it.get("tags") or [] if t.startswith("license:")), "") or "?"
        extra = it.get("pipeline_tag") or it.get("sdk") or ""
        out.append(f"{i}. {it.get('id')}  ♥{it.get('likes', 0)}" + (f"  ⬇{it.get('downloads')}" if it.get("downloads") is not None else "")
                   + f"  [{extra}]  Lizenz: {lic}\n   {_hf_url(kind, it.get('id'))}")
    out.append("\nMit hf_read Details/Dateien ansehen, mit hf_download den Code (z.B. eines Space) holen.")
    return _cut("\n".join(out))


def tool_hf_read(repo_id, kind="models", path=""):
    from urllib.parse import quote
    kind = _hf_kind(kind)
    rid = _repo_name(repo_id)
    if not path:
        info = _json(f"{HF_BASE}/api/{kind}/{rid}")
        lic = _hf_license(info)
        ok, warn = _license_ok(lic)
        files = [s.get("rfilename", "") for s in info.get("siblings") or []]
        card = ""
        try:
            card = _get(f"{_hf_url(kind, rid)}/resolve/main/README.md", accept="*/*", limit=400_000).decode("utf-8", "replace")[:6000]
        except Exception:
            card = "(keine Beschreibung)"
        return _cut(f"{rid} ({kind})  Lizenz: {lic or 'unbekannt'} -> {'frei verwendbar' if ok else 'NICHT als frei erkannt'}"
                    f"{(' – ' + warn) if warn else ''}\n{('SDK: ' + info['sdk'] + chr(10)) if info.get('sdk') else ''}"
                    f"Dateien ({len(files)}):\n" + "\n".join(files[:200]) + f"\n\nBeschreibung:\n{card}")
    raw = _get(f"{_hf_url(kind, rid)}/resolve/main/{quote(str(path).strip('/'))}", accept="*/*", limit=400_000)
    return _cut(raw.decode("utf-8", "replace"))


def tool_hf_download(repo_id, kind="spaces", folder=""):
    from urllib.parse import quote
    kind = _hf_kind(kind)
    rid = _repo_name(repo_id)
    info = _json(f"{HF_BASE}/api/{kind}/{rid}")
    lic = _hf_license(info)
    ok, warn = _license_ok(lic)
    if not ok:
        return (f"Abgelehnt: {rid} hat {'keine Lizenzangabe' if not lic else 'die Lizenz ' + lic}, die nicht als frei erkannt wird. "
                "Nimm ein anderes Projekt mit offener Lizenz.")
    d = _target_dir(folder, rid.split("/")[-1])
    got, skipped, total = [], [], 0
    for s in info.get("siblings") or []:
        fn = s.get("rfilename", "")
        if not fn or fn.lower().endswith(SKIP_EXT):
            skipped.append(fn)
            continue
        if len(got) >= 300 or total > 50_000_000:
            skipped.append(fn)
            continue
        try:
            data = _get(f"{_hf_url(kind, rid)}/resolve/main/{quote(fn)}", accept="*/*", limit=10_000_000)
        except Exception:
            skipped.append(fn)
            continue
        if len(data) > 10_000_000:
            skipped.append(fn)
            continue
        dst = os.path.abspath(os.path.join(d, fn))
        if not dst.startswith(os.path.abspath(d) + os.sep):
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, "wb") as f:
            f.write(data)
        got.append(fn)
        total += len(data)
    if not got:
        return "Nichts heruntergeladen (nur große Modelldateien vorhanden oder Fehler)."
    _note_source(d, [f"## {rid} (Hugging Face {kind})", f"- Quelle: {_hf_url(kind, rid)}", f"- Lizenz: {lic}",
                     f"- Heruntergeladen: {time.strftime('%Y-%m-%d %H:%M')}"])
    sk = f" Übersprungen (große Modell-/Datendateien, die Ollama nicht braucht): {', '.join(skipped[:10])}" if skipped else ""
    return {"result": f"Heruntergeladen: {rid} -> {d} ({len(got)} Dateien, {round(total / 1e6, 1)} MB, Lizenz {lic}).{sk}"
                      f"{(' Hinweis: ' + warn) if warn else ''}", "folder": d}


# ---- Screenshots für die Design-Prüfung (Edge/Chrome unsichtbar im Hintergrund)
SCREENS = os.path.join(PROJECTS, ".screens")


def find_browser():
    cands = [os.environ.get("OLLAMA_LAUNCHER_BROWSER")]
    if os.name == "nt":
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    cands += [shutil.which(x) for x in ("msedge", "chrome", "chromium", "google-chrome", "chromium-browser")]
    return next((c for c in cands if c and os.path.isfile(c)), None)


def take_screenshot(url, width, height, out):
    import tempfile
    exe = find_browser()
    if not exe:
        raise RuntimeError("Kein Edge/Chrome gefunden – Screenshots nicht möglich.")
    prof = tempfile.mkdtemp(prefix="ollama_shot_")  # eigenes Profil: stört dein offenes Edge nicht
    cmd = [exe, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
           "--no-default-browser-check", "--mute-audio", "--disable-extensions", f"--user-data-dir={prof}",
           f"--window-size={width},{height}", "--virtual-time-budget=4000", f"--screenshot={out}", url]
    if os.name != "nt" and hasattr(os, "geteuid") and os.geteuid() == 0:
        cmd.insert(1, "--no-sandbox")
    try:
        subprocess.run(cmd, capture_output=True, timeout=60, creationflags=NO_WINDOW if os.name == "nt" else 0)
    except subprocess.TimeoutExpired:
        pass
    finally:
        shutil.rmtree(prof, ignore_errors=True)
    return os.path.isfile(out) and os.path.getsize(out) > 0


def tool_review_design(path):
    import base64
    r = tool_show_preview(path)
    if not isinstance(r, dict):
        return r
    os.makedirs(SCREENS, exist_ok=True)
    stem = _safe_folder(os.path.relpath(r["path"], PROJECTS).replace(os.sep, "_"))
    shots, urls = [], []
    for label, w, h in (("desktop", 1280, 800), ("handy", 390, 844)):
        out = os.path.join(SCREENS, f"{stem}-{label}.png")
        if os.path.exists(out):
            os.remove(out)
        if take_screenshot(r["preview"], w, h, out):
            with open(out, "rb") as f:
                shots.append(base64.b64encode(f.read()).decode())
            urls.append(f"http://localhost:{PREVIEW_PORT}/.screens/{os.path.basename(out)}?t={int(time.time())}")
    if not shots:
        return "Screenshots konnten nicht erstellt werden (Browser-Fehler)."
    return {"result": f"{len(shots)} Screenshots erstellt (Desktop 1280px, Handy 390px).", "screens": shots, "screen_urls": urls}


# ---- Python-/Node-Apps installieren, starten, testen
PROCS = {}
RUNLOGS = os.path.join(PROJECTS, ".run")


def _proj_root(path):
    p = _path(path, PROJECTS)
    if os.path.isfile(p):
        p = os.path.dirname(p)
    if not (in_projects(p) and os.path.isdir(p)):
        raise RuntimeError(f"Kein Projektordner: {p} (Apps laufen nur in {PROJECTS})")
    return p


def _venv_bin(root):
    return os.path.join(root, ".venv", "Scripts" if os.name == "nt" else "bin")


def _app_env(root):
    env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8", FORCE_COLOR="0", NO_COLOR="1",
               BROWSER="none", GRADIO_ANALYTICS_ENABLED="False")
    vb = _venv_bin(root)
    if os.path.isdir(vb):
        env["PATH"] = vb + os.pathsep + env.get("PATH", "")
        env["VIRTUAL_ENV"] = os.path.dirname(vb)
    return env


def _python_exe():
    exe = sys.executable or "python"
    if os.name == "nt" and exe.lower().endswith("pythonw.exe"):
        cand = exe[:-len("pythonw.exe")] + "python.exe"
        if os.path.isfile(cand):
            return cand
    return exe


def _run(cmd, cwd, env, timeout):
    r = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       timeout=timeout, shell=isinstance(cmd, str), creationflags=NO_WINDOW if os.name == "nt" else 0)
    return r.returncode, ((r.stdout or "") + (r.stderr or "")).strip()


def tool_setup_project(path):
    root = _proj_root(path)
    env, out = _app_env(root), []
    if os.path.isfile(os.path.join(root, "requirements.txt")):
        if not os.path.isdir(_venv_bin(root)):
            code, txt = _run([_python_exe(), "-m", "venv", ".venv"], root, env, 300)
            out.append(f"Python-Umgebung (.venv) angelegt: Exit {code}" + (("\n" + txt[-1500:]) if code else ""))
            env = _app_env(root)
        pip = os.path.join(_venv_bin(root), "pip.exe" if os.name == "nt" else "pip")
        code, txt = _run([pip, "install", "-r", "requirements.txt", "--disable-pip-version-check"], root, env, 900)
        out.append(f"pip install -r requirements.txt: Exit {code}\n{txt[-3000:]}")
    if os.path.isfile(os.path.join(root, "package.json")):
        npm = shutil.which("npm.cmd" if os.name == "nt" else "npm") or shutil.which("npm")
        if not npm:
            out.append("Node.js/npm nicht gefunden. Installieren mit: winget install OpenJS.NodeJS.LTS")
        else:
            code, txt = _run([npm, "install", "--no-audit", "--no-fund"], root, env, 900)
            out.append(f"npm install: Exit {code}\n{txt[-3000:]}")
    if not out:
        return "Weder requirements.txt noch package.json gefunden – nichts zu installieren. Lege sie bei Bedarf mit write_file an."
    return _cut("\n\n".join(out))


def _read_log(info, n=3000):
    try:
        with open(info["log"], encoding="utf-8", errors="replace") as f:
            return f.read()[-n:]
    except OSError:
        return ""


def _app_status(pid):
    import re
    info = PROCS.get(pid)
    if not info:
        return {"result": f"Kein laufendes Programm mit der Nummer {pid}."}
    code = info["proc"].poll()
    log = _read_log(info)
    m = re.findall(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1?\]):(\d{2,5})[^\s'\"<>]*", log)
    url = f"http://localhost:{m[-1]}/" if m else None
    state = "läuft noch" if code is None else f"beendet (Exit-Code {code}{' = Fehler' if code else ' = ok'})"
    res = (f"Programm {pid} ({info['cmd']}) {state}." + (f" Erreichbar unter {url}" if url and code is None else "") +
           f"\n\nAusgabe (Ende):\n{log or '(noch keine Ausgabe)'}")
    out = {"result": _cut(res), "proc": pid}
    if url and code is None:
        out["app_url"] = url
    return out


def tool_start_app(path, command, wait=8):
    root = _proj_root(path)
    os.makedirs(RUNLOGS, exist_ok=True)
    pid = f"app{len(PROCS) + 1}"
    log = os.path.join(RUNLOGS, f"{pid}-{_safe_folder(os.path.basename(root))}.log")
    flags = (NEW_GROUP | NO_WINDOW) if os.name == "nt" else 0
    with open(log, "w", encoding="utf-8") as lf:
        proc = subprocess.Popen(str(command), cwd=root, env=_app_env(root), shell=True, stdout=lf, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, creationflags=flags, start_new_session=(os.name != "nt"))
    PROCS[pid] = {"proc": proc, "cmd": str(command)[:120], "log": log, "root": root}
    end = time.time() + max(2, min(float(wait or 8), 60))
    while time.time() < end and proc.poll() is None:
        time.sleep(0.3)
    return _app_status(pid)


def tool_app_output(proc):
    return _app_status(str(proc))


def stop_proc(pid):
    info = PROCS.get(pid)
    if not info or info["proc"].poll() is not None:
        return False
    p = info["proc"]
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(p.pid)], capture_output=True, creationflags=NO_WINDOW)
        else:
            import signal
            os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        p.wait(timeout=10)
    except Exception:
        p.kill()
    return True


def tool_stop_app(proc):
    pid = str(proc)
    if pid not in PROCS:
        return f"Kein Programm {pid}. Laufend: {', '.join(k for k, v in PROCS.items() if v['proc'].poll() is None) or 'keine'}"
    return f"Programm {pid} gestoppt." if stop_proc(pid) else f"Programm {pid} lief schon nicht mehr."


def stop_all_apps():
    for pid in list(PROCS):
        stop_proc(pid)


def tool_check_preview(path):
    r = tool_show_preview(path)
    if isinstance(r, dict):
        return {"result": "Prüfe…", "check": r["preview"]}
    return r


def tool_show_preview(path):
    p = _path(path, PROJECTS)
    if os.path.isdir(p):
        p = os.path.join(p, "index.html")
    if not os.path.isfile(p):
        return f"Datei nicht gefunden: {p}"
    if not in_projects(p):
        return f"Vorschau geht nur für Dateien in {PROJECTS}"
    rel = os.path.relpath(p, PROJECTS).replace(os.sep, "/")
    url = f"http://localhost:{PREVIEW_PORT}/" + urllib.request.quote(rel)
    return {"result": f"Vorschau wird dem Nutzer angezeigt: {url}", "preview": url, "path": p}


def tool_update_plan(steps=None):
    if not isinstance(steps, list):
        return "steps muss eine Liste sein."
    return {"result": "Plan aktualisiert.", "plan": steps}


TOOLS = {
    "edit_file": tool_edit_file,
    "fetch_url": tool_fetch_url,
    "web_search": tool_web_search,
    "review_design": tool_review_design,
    "setup_project": tool_setup_project,
    "start_app": tool_start_app,
    "app_output": tool_app_output,
    "stop_app": tool_stop_app,
    "github_search": tool_github_search,
    "github_read": tool_github_read,
    "github_download": tool_github_download,
    "hf_search": tool_hf_search,
    "hf_read": tool_hf_read,
    "hf_download": tool_hf_download,
    "check_preview": tool_check_preview,
    "show_preview": tool_show_preview,
    "update_plan": tool_update_plan,
    "list_dir": tool_list_dir,
    "read_file": tool_read_file,
    "write_file": tool_write_file,
    "run_command": tool_run_command,
    "open_item": tool_open_item,
}


def run_tool(name, args):
    fn = TOOLS.get(name)
    if not fn:
        return f"Unbekanntes Werkzeug: {name}"
    if not isinstance(args, dict):
        args = {}
    try:
        return fn(**args)
    except TypeError as e:
        return f"Falsche Parameter für {name}: {e}"
    except Exception as e:
        return f"Fehler bei {name}: {type(e).__name__}: {e}"


def allowed(handler):
    """Nur Anfragen von dieser Oberfläche selbst zulassen.
    Schützt davor, dass fremde Webseiten über den Launcher Modelle laden/löschen
    (CSRF) oder per DNS-Rebinding zugreifen."""
    port = handler.server.server_address[1]
    ok_hosts = {f"localhost:{port}", f"127.0.0.1:{port}"}
    if handler.headers.get("Host", "") not in ok_hosts:
        return False
    origin = handler.headers.get("Origin")
    if origin and origin not in {f"http://{h}" for h in ok_hosts}:
        return False
    site = handler.headers.get("Sec-Fetch-Site")
    if site and site not in ("same-origin", "none"):
        return False
    return True


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _guard(self):
        if allowed(self):
            return True
        self.close_connection = True
        self._send(403, '{"error":"Zugriff verweigert"}')
        return False

    def _send(self, code, body, ctype="application/json"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _proxy(self, method):
        path = self.path.split("?", 1)[0]
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None
        if (method, path) not in PROXY:
            return self._send(404, '{"error":"unbekannt"}')
        req = urllib.request.Request(OLLAMA + path, data=body, method=method,
                                     headers={"Content-Type": "application/json"})
        try:
            resp = urllib.request.urlopen(req, timeout=3600)
        except urllib.error.HTTPError as e:
            return self._send(e.code, e.read() or b'{"error":"Ollama-Fehler"}')
        except Exception as e:
            return self._send(502, json.dumps({"error": f"Ollama nicht erreichbar: {e}"}))
        # Zeilenweise weiterreichen (Streaming) mit Chunked-Encoding
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.headers.get("Content-Type", "application/json"))
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            with resp:
                while True:
                    line = resp.readline()
                    if not line:
                        break
                    self.wfile.write(b"%x\r\n%s\r\n" % (len(line), line))
                    self.wfile.flush()
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            self.close_connection = True  # "Stopp" gedrückt oder Tab geschlossen

    def do_GET(self):
        if self.path == MARKER:
            return self._send(200, '{"ok":true}')
        if not self._guard():
            return
        if self.path in ("/", "/index.html"):
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if self.path == "/favicon.ico":
            return self._send(204, b"")
        if self.path == "/__info":
            return self._send(200, json.dumps({"projects": PROJECTS, "preview_port": PREVIEW_PORT}, ensure_ascii=False))
        if self.path.startswith("/__versions?"):
            from urllib.parse import parse_qs, urlparse
            full = project_dir(parse_qs(urlparse(self.path).query).get("name", [""])[0])
            if not full:
                return self._send(404, '{"error":"Projekt nicht gefunden"}')
            return self._send(200, json.dumps({"git": bool(find_git()), "versions": git_versions(full),
                                               "token": bool(gh_token())}, ensure_ascii=False))
        if self.path == "/__apps":
            return self._send(200, json.dumps([{"id": k, "cmd": v["cmd"], "running": v["proc"].poll() is None,
                                                "project": os.path.basename(v["root"])} for k, v in PROCS.items()], ensure_ascii=False))
        if self.path == "/__projects":
            return self._send(200, json.dumps({"projects": list_projects(), "preview_port": PREVIEW_PORT}, ensure_ascii=False))
        if self.path.startswith("/__zip?"):
            from urllib.parse import parse_qs, urlparse
            full = project_dir(parse_qs(urlparse(self.path).query).get("name", [""])[0])
            if not full:
                return self._send(404, '{"error":"Projekt nicht gefunden"}')
            data = zip_project(full)
            safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in os.path.basename(full))
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", f'attachment; filename="{safe}.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if self.path.startswith("/__project_info?"):
            from urllib.parse import parse_qs, urlparse
            pth = _path(parse_qs(urlparse(self.path).query).get("path", [""])[0], PROJECTS)
            if not (in_projects(pth) and os.path.isdir(pth)):
                return self._send(404, '{"error":"kein Projekt"}')
            return self._send(200, json.dumps({"tree": project_tree(pth), "notes": project_notes(pth)}, ensure_ascii=False))
        if self.path.startswith("/__check?"):
            from urllib.parse import parse_qs, urlparse
            q = parse_qs(urlparse(self.path).query).get("path", [""])[0]
            p = _path(q, PROJECTS)
            return self._send(200, json.dumps({"path": p, "in_projects": in_projects(p),
                                               "exists": os.path.exists(p)}, ensure_ascii=False))
        self._proxy("GET")

    def do_POST(self):
        if not self._guard():
            return
        if self.path == "/__tool":
            length = int(self.headers.get("Content-Length") or 0)
            try:
                req = json.loads(self.rfile.read(length) or b"{}")
            except ValueError:
                return self._send(400, '{"error":"ungültig"}')
            name, args = req.get("name"), req.get("arguments") or {}
            print(f"[Agent] {name} {json.dumps(args, ensure_ascii=False)[:200]}")
            result = run_tool(name, args)
            out = result if isinstance(result, dict) else {"result": result}
            if name in ("write_file", "edit_file") and isinstance(args, dict):
                out["path"] = _path(args.get("path"), PROJECTS)
            return self._send(200, json.dumps(out, ensure_ascii=False))
        if self.path == "/__notes":
            length = int(self.headers.get("Content-Length") or 0)
            try:
                req = json.loads(self.rfile.read(length) or b"{}")
            except ValueError:
                return self._send(400, '{"error":"ungültig"}')
            pth = _path(req.get("project"), PROJECTS)
            if not (in_projects(pth) and os.path.isdir(pth)):
                return self._send(404, '{"error":"kein Projekt"}')
            append_notes(pth, str(req.get("request") or "")[:300], [str(f)[:80] for f in (req.get("files") or [])][:30])
            return self._send(200, '{"ok":true}')
        if self.path in ("/__git_commit", "/__restore", "/__publish", "/__gh_token"):
            length = int(self.headers.get("Content-Length") or 0)
            try:
                req = json.loads(self.rfile.read(length) or b"{}")
            except ValueError:
                return self._send(400, '{"error":"ungültig"}')
            try:
                if self.path == "/__gh_token":
                    tok = str(req.get("token") or "").strip()
                    os.makedirs(os.path.dirname(TOKEN_FILE), exist_ok=True)
                    if tok:
                        with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                            f.write(tok)
                    elif os.path.exists(TOKEN_FILE):
                        os.remove(TOKEN_FILE)
                    return self._send(200, '{"ok":true}')
                root = _path(req.get("project"), PROJECTS) if req.get("project") else project_dir(req.get("name"))
                if not root or not (in_projects(root) and os.path.isdir(root)):
                    return self._send(404, '{"error":"Projekt nicht gefunden"}')
                if self.path == "/__git_commit":
                    sha = git_commit(root, str(req.get("message") or "Änderung"))
                    return self._send(200, json.dumps({"sha": sha, "git": bool(find_git())}))
                if self.path == "/__restore":
                    sha = git_restore(root, str(req.get("sha") or ""))
                    print(f"[Versionen] {os.path.basename(root)} -> {req.get('sha')}")
                    return self._send(200, json.dumps({"ok": True, "sha": sha}))
                res = publish_github(root)
                print(f"[Veröffentlicht] {res['url']}")
                return self._send(200, json.dumps(res, ensure_ascii=False))
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False))
        if self.path == "/__stop_app":
            length = int(self.headers.get("Content-Length") or 0)
            try:
                pid = str(json.loads(self.rfile.read(length) or b"{}").get("id"))
            except ValueError:
                return self._send(400, '{"error":"ungültig"}')
            return self._send(200, json.dumps({"stopped": stop_proc(pid)}))
        if self.path in ("/__undo", "/__open_project"):
            length = int(self.headers.get("Content-Length") or 0)
            try:
                req = json.loads(self.rfile.read(length) or b"{}")
            except ValueError:
                return self._send(400, '{"error":"ungültig"}')
            if self.path == "/__undo":
                results, blocked, done = [], set(), []
                for u in (req.get("ids") or []):
                    e = next((x for x in _journal() if x.get("id") == u), None)
                    if e and e.get("path") in blocked:
                        continue
                    r = undo_change(u)
                    results.append(r)
                    if r[0]:
                        done.append(u)
                    if not r[0] and e:
                        blocked.add(e.get("path"))
                ok = all(r[0] for r in results)
                print("[Rückgängig] " + "; ".join(r[1] for r in results))
                return self._send(200 if ok else 409, json.dumps(
                    {"ok": ok, "done": done, "messages": [r[1] for r in results]}, ensure_ascii=False))
            full = project_dir(req.get("name"))
            if not full:
                return self._send(404, '{"error":"Projekt nicht gefunden"}')
            try:
                tool_open_item(full)
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False))
            return self._send(200, '{"ok":true}')
        if self.path == "/__shutdown":
            self._send(200, '{"ok":true}')
            threading.Thread(target=SERVER.shutdown, daemon=True).start()
            return
        self._proxy("POST")

    def do_DELETE(self):
        if not self._guard():
            return
        self._proxy("DELETE")


REPORTER = (b"<script>(function(){var E=[],sent=0;function info(){var b=document.body;return{title:document.title,"
    b"text:b?b.innerText.trim().length:0,elements:document.getElementsByTagName('*').length,"
    b"images:document.images.length,links:document.links.length,canvases:document.getElementsByTagName('canvas').length,width:document.documentElement.scrollWidth,"
    b"viewport:window.innerWidth}}"
    b"function s(){try{parent.postMessage({__ollamaPreview:1,href:location.href,errors:E,info:info()},'*')}catch(e){}}"
    b"window.addEventListener('error',function(e){var t=e.target;if(t&&t!==window&&(t.src||t.href)){"
    b"E.push('Datei nicht gefunden: '+(t.src||t.href).split('/').pop())}else{E.push((e.message||'Fehler')+"
    b"(e.filename?' ('+e.filename.split('/').pop()+':'+e.lineno+')':''))}},true);"
    b"window.addEventListener('unhandledrejection',function(e){E.push('Promise-Fehler: '+(e.reason&&e.reason.message||e.reason))});"
    b"var ce=console.error;console.error=function(){E.push('console.error: '+[].slice.call(arguments).join(' '));"
    b"ce.apply(console,arguments)};window.addEventListener('message',function(e){if(e.data==='__ollamaReport')s()});"
    b"window.addEventListener('load',function(){setTimeout(s,400)})})();</script>")


SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", ".screens", ".backups", "dist", "build", ".next"}
NOTES_HEAD = ("# Projekt-Notizen\n\nDiese Datei ist das Gedächtnis des Agenten für dieses Projekt. "
              "Er liest sie bei jedem Auftrag.\n\n## Aufbau & Entscheidungen\n\n- (noch leer)\n\n## Verlauf\n")


def project_tree(root, limit=120):
    out = []
    for dp, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        depth = os.path.relpath(dp, root).count(os.sep) + (0 if dp == root else 1)
        if depth > 3:
            dirs[:] = []
            continue
        for fn in sorted(files):
            rel = os.path.relpath(os.path.join(dp, fn), root).replace(os.sep, "/")
            try:
                out.append(f"{rel} ({os.path.getsize(os.path.join(dp, fn))} B)")
            except OSError:
                out.append(rel)
            if len(out) >= limit:
                return "\n".join(out) + "\n… (weitere Dateien)"
    return "\n".join(out)


def project_notes(root, limit=3000):
    try:
        with open(os.path.join(root, "AGENT.md"), encoding="utf-8") as f:
            t = f.read()
    except OSError:
        return ""
    if len(t) <= limit:
        return t
    head, _, hist = t.partition("## Verlauf")
    return head[:limit // 2] + "## Verlauf (neueste Einträge)\n…" + hist[-(limit // 2):]


def append_notes(root, request, files):
    p = os.path.join(root, "AGENT.md")
    new = not os.path.exists(p)
    with open(p, "a", encoding="utf-8") as f:
        if new:
            f.write(NOTES_HEAD)
        f.write(f"- {time.strftime('%Y-%m-%d %H:%M')}: «{request}» → {', '.join(files) or '-'}\n")


# ---- Git-Versionen
def find_git():
    g = shutil.which("git")
    if g:
        return g
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs")):
        if base:
            p = os.path.join(base, "Git", "cmd", "git.exe")
            if os.path.isfile(p):
                return p
    return None


def git(cwd, *args, check=True):
    exe = find_git()
    if not exe:
        raise RuntimeError("Git ist nicht installiert. In der Eingabeaufforderung: winget install Git.Git")
    r = subprocess.run([exe, "-c", "user.name=Ollama Agent", "-c", "user.email=agent@localhost",
                        "-c", "core.autocrlf=false", "-c", "core.quotepath=false", *args],
                       cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       timeout=120, creationflags=NO_WINDOW if os.name == "nt" else 0)
    if check and r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip()[:400])
    return r.stdout


GITIGNORE = "node_modules/\n.venv/\nvenv/\n__pycache__/\n*.pyc\n.DS_Store\n"


def git_commit(root, message):
    if not find_git():
        return None
    if not os.path.isdir(os.path.join(root, ".git")):
        git(root, "init")
        git(root, "symbolic-ref", "HEAD", "refs/heads/main")
        if not os.path.exists(os.path.join(root, ".gitignore")):
            with open(os.path.join(root, ".gitignore"), "w", encoding="utf-8") as f:
                f.write(GITIGNORE)
    git(root, "add", "-A")
    if not git(root, "status", "--porcelain").strip():
        return None
    git(root, "commit", "-q", "-m", message[:200])
    return git(root, "rev-parse", "--short", "HEAD").strip()


def git_versions(root):
    if not os.path.isdir(os.path.join(root, ".git")):
        return []
    out = git(root, "log", "-n", "40", "--date=format:%d.%m.%Y %H:%M", "--pretty=format:%h\x1f%ad\x1f%s", check=False)
    return [dict(zip(("sha", "date", "msg"), l.split("\x1f"))) for l in out.splitlines() if l.count("\x1f") == 2]


def git_restore(root, sha):
    import re
    if not re.fullmatch(r"[0-9a-f]{4,40}", sha or ""):
        raise RuntimeError("Ungültige Version.")
    git_commit(root, "Automatisch gesichert vor Wiederherstellen")
    msg = git(root, "log", "-1", "--pretty=%s", sha).strip()
    git(root, "restore", "--source=" + sha, "--staged", "--worktree", ":/")
    return git_commit(root, f"Wiederhergestellt: Version {sha} ({msg[:80]})") or sha


# ---- Veröffentlichen auf GitHub Pages (nur per Klick des Nutzers)
TOKEN_FILE = os.path.join(os.path.expanduser("~"), ".ollama_launcher", "github_token")


def gh_token():
    try:
        with open(TOKEN_FILE, encoding="utf-8") as f:
            t = f.read().strip()
        if t:
            return t  # in der App eingetragener Token hat Vorrang
    except OSError:
        pass
    return (os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN") or "").strip()


def gh_api(method, path, body=None, ok=(200, 201, 204)):
    tok = gh_token()
    if not tok:
        raise RuntimeError("Kein GitHub-Token hinterlegt.")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(GITHUB_API + path, data=data, method=method, headers={
        "Authorization": "Bearer " + tok, "Accept": "application/vnd.github+json",
        "User-Agent": "OllamaLauncher/1.0", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            j = json.loads(raw)
        except ValueError:
            j = {"message": raw.decode("utf-8", "replace")[:200]}
        if e.code in ok:
            return e.code, j
        return e.code, j


def publish_github(root):
    import base64
    import hashlib
    from urllib.parse import quote
    if not os.path.isfile(os.path.join(root, "index.html")):
        raise RuntimeError("Im Projekt fehlt eine index.html im Hauptordner – GitHub Pages braucht sie als Startseite.")
    st, user = gh_api("GET", "/user")
    if st != 200:
        raise RuntimeError("GitHub-Token ungültig oder ohne Rechte (" + str(user.get("message")) + ").")
    login = user["login"]
    repo = _safe_folder(os.path.basename(root)).lower()
    st, info = gh_api("GET", f"/repos/{login}/{repo}")
    if st == 404:
        st, info = gh_api("POST", "/user/repos", {"name": repo, "description": "Erstellt mit dem Sulaiman Durrani Open Source KI-Agent", "private": False})
        if st not in (200, 201):
            raise RuntimeError("Repository konnte nicht angelegt werden: " + str(info.get("message")))
    elif st != 200:
        raise RuntimeError("GitHub-Fehler: " + str(info.get("message")))
    st, tree = gh_api("GET", f"/repos/{login}/{repo}/git/trees/main?recursive=1")
    remote = {t["path"]: t["sha"] for t in (tree.get("tree") or []) if t.get("type") == "blob"} if st == 200 else {}
    up = same = 0
    for dp, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fn in files:
            full = os.path.join(dp, fn)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            if rel in ("AGENT.md",) or os.path.getsize(full) > 25_000_000 or up + same >= 800:
                continue
            with open(full, "rb") as f:
                data = f.read()
            blob = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
            if remote.get(rel) == blob:
                same += 1
                continue
            body = {"message": f"Aktualisiert: {rel}", "content": base64.b64encode(data).decode(), "branch": "main"}
            if rel in remote:
                body["sha"] = remote[rel]
            st, res = gh_api("PUT", f"/repos/{login}/{repo}/contents/{quote(rel)}", body)
            if st not in (200, 201):
                raise RuntimeError(f"Upload von {rel} fehlgeschlagen: {res.get('message')}")
            up += 1
    st, res = gh_api("POST", f"/repos/{login}/{repo}/pages", {"source": {"branch": "main", "path": "/"}}, ok=(200, 201, 204, 409))
    url = f"https://{login.lower()}.github.io/{repo}/"
    return {"url": url, "repo": f"https://github.com/{login}/{repo}", "uploaded": up, "unchanged": same,
            "note": "Die Seite ist meist nach 1–2 Minuten erreichbar." if st != 409 else "GitHub Pages war schon eingerichtet."}


def list_projects():
    out = []
    if not os.path.isdir(PROJECTS):
        return out
    for name in os.listdir(PROJECTS):
        full = os.path.join(PROJECTS, name)
        if name.startswith(".") or not os.path.isdir(full):
            continue
        count, newest = 0, os.path.getmtime(full)
        for root, dirs, files in os.walk(full):
            for fn in files:
                count += 1
                try:
                    newest = max(newest, os.path.getmtime(os.path.join(root, fn)))
                except OSError:
                    pass
            if count > 2000:
                break
        out.append({"name": name, "path": full, "files": count, "mtime": newest,
                    "index": os.path.isfile(os.path.join(full, "index.html"))})
    return sorted(out, key=lambda x: -x["mtime"])


def project_dir(name):
    name = str(name or "")
    full = os.path.join(PROJECTS, name)
    if not name or name != os.path.basename(name) or name.startswith(".") or not os.path.isdir(full):
        return None
    return full


def zip_project(full):
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(full):
            for fn in files:
                fp = os.path.join(root, fn)
                z.write(fp, os.path.relpath(fp, os.path.dirname(full)))
    return buf.getvalue()


class PreviewHandler(SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def list_directory(self, path):
        self.send_error(404, "Keine Ordneransicht")
        return None

    def send_head(self):
        path = self.translate_path(self.path)
        if os.path.isdir(path):
            if not self.path.split("?")[0].endswith("/"):
                return super().send_head()
            path = os.path.join(path, "index.html")
        if not path.lower().endswith((".html", ".htm")) or not os.path.isfile(path):
            return super().send_head()
        import io
        with open(path, "rb") as f:
            data = f.read()
        import re
        # crossorigin an Skripte, damit echte Fehlermeldungen (Text + Zeile) ankommen
        data = re.sub(rb"<script(?![^>]*crossorigin)(?=[^>]*\ssrc=)", b'<script crossorigin="anonymous"', data, flags=re.I)
        low = data.lower()
        i = low.find(b"<head>")
        data = data[:i + 6] + REPORTER + data[i + 6:] if i >= 0 else REPORTER + data
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        return io.BytesIO(data)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        # Nur für die abgeschottete Vorschau (Origin "null"), nicht für fremde Webseiten
        if self.headers.get("Origin") == "null":
            self.send_header("Access-Control-Allow-Origin", "null")
        super().end_headers()


def start_preview():
    global PREVIEW_PORT
    os.makedirs(PROJECTS, exist_ok=True)
    for port in range(9765, 9786):
        if port_free(port):
            srv = ThreadingHTTPServer(("127.0.0.1", port), partial(PreviewHandler, directory=PROJECTS))
            srv.daemon_threads = True
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            PREVIEW_PORT = port
            return srv
    return None


def launcher_running(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{MARKER}", timeout=1) as r:
            return r.status == 200
    except Exception:
        return False


def port_free(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def open_browser(url):
    if os.environ.get("OLLAMA_LAUNCHER_NO_BROWSER") != "1":
        webbrowser.open(url)


# Ohne Konsole gestartet (pythonw)? Dann Ausgaben in eine Log-Datei
# und Fehler als Windows-Meldungsfenster anzeigen.
HEADLESS = sys.stdout is None or sys.stderr is None
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Ollama_Start.log")
if HEADLESS:
    try:
        sys.stdout = sys.stderr = open(LOG_PATH, "w", encoding="utf-8", buffering=1)
    except Exception:
        sys.stdout = sys.stderr = open(os.devnull, "w")


def fail(msg):
    print("[!] " + msg)
    if HEADLESS:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "Sulaiman Durrani KI-Agent", 0x10)
    else:
        input("\nEnter zum Beenden...")
    return 1


def main():
    global SERVER
    print("=" * 52)
    print("   SULAIMAN DURRANI OPEN SOURCE KI-AGENT   " + time.strftime("%Y-%m-%d %H:%M:%S"))
    print("=" * 52)

    if launcher_running(UI_PORT):
        print(f"[OK] Läuft bereits – öffne http://localhost:{UI_PORT}")
        open_browser(f"http://localhost:{UI_PORT}")
        if not HEADLESS:
            time.sleep(2)
        return 0

    if not ensure_ollama():
        if find_ollama() is None:
            return fail("Ollama wurde nicht gefunden.\n\nBitte installieren: https://ollama.com/download")
        return fail("Ollama antwortet nicht (Port 11434).\n\nStarte die Ollama-App einmal von Hand und versuch es dann erneut.")

    port = UI_PORT
    while not port_free(port):
        port += 1
        if port > UI_PORT + 20:
            return fail("Kein freier Port zwischen 8765 und 8785 gefunden.")
    start_preview()
    print(f"[OK] Projektordner: {PROJECTS} (Vorschau-Port {PREVIEW_PORT})")
    SERVER = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    SERVER.daemon_threads = True
    url = f"http://localhost:{port}"
    print(f"[OK] Chat läuft auf {url}")
    if HEADLESS:
        print("     Läuft im Hintergrund. Beenden: Knopf „Beenden“ unten links im Chat.")
    else:
        print("     Dieses Fenster offen lassen. Beenden: Fenster schließen, Strg+C")
        print("     oder Knopf „Beenden“ unten links im Chat.")
    open_browser(url)
    try:
        SERVER.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop_all_apps()
    print("[OK] Beendet.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        import traceback
        traceback.print_exc()
        sys.exit(fail("Unerwarteter Fehler:\n\n" + traceback.format_exc(limit=3)
                      + ("\nDetails: " + LOG_PATH if HEADLESS else "")))
