@echo off
title SD Bewerbungsstudio
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-windows.ps1"
pause
