$ErrorActionPreference = "SilentlyContinue"
$port = 8791
$root = $PSScriptRoot

Add-Type -AssemblyName System.Net.HttpListener -ErrorAction SilentlyContinue

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
try {
    $listener.Start()
} catch {
    Write-Host "Port $port ist belegt, versuche einen anderen Port ..."
    $port = 8792
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$port/")
    $listener.Start()
}

Write-Host "========================================"
Write-Host " SD Bewerbungsstudio wird gestartet ..."
Write-Host " Adresse: http://localhost:$port/"
Write-Host " Dieses Fenster bitte offen lassen, solange du die App benutzt."
Write-Host " Zum Beenden: Fenster schliessen oder Strg+C druecken."
Write-Host "========================================"

Start-Process "http://localhost:$port/index.html"

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".svg"  = "image/svg+xml"
    ".png"  = "image/png"
    ".css"  = "text/css; charset=utf-8"
    ".ico"  = "image/x-icon"
}

while ($listener.IsListening) {
    $context = $null
    try { $context = $listener.GetContext() } catch { break }
    if ($null -eq $context) { continue }
    $request = $context.Request
    $response = $context.Response
    try {
        $localPath = [System.Uri]::UnescapeDataString($request.Url.LocalPath).TrimStart('/')
        if ([string]::IsNullOrEmpty($localPath)) { $localPath = "index.html" }
        $filePath = Join-Path $root $localPath
        $fullRoot = (Resolve-Path $root).Path
        $resolved = $null
        if (Test-Path $filePath -PathType Leaf) { $resolved = (Resolve-Path $filePath).Path }

        if ($resolved -and $resolved.StartsWith($fullRoot)) {
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $contentType = $mimeTypes[$ext]
            if (-not $contentType) { $contentType = "application/octet-stream" }
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $response.ContentType = $contentType
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $msg = [System.Text.Encoding]::UTF8.GetBytes("404 - Datei nicht gefunden")
            $response.OutputStream.Write($msg, 0, $msg.Length)
        }
    } catch {
        $response.StatusCode = 500
    } finally {
        $response.OutputStream.Close()
    }
}
