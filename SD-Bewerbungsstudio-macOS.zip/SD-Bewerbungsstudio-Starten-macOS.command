#!/bin/bash
cd "$(dirname "$0")/app" || exit 1
PORT=8791

PYTHON_BIN=""
if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python"
fi

if [ -z "$PYTHON_BIN" ]; then
    echo "Python 3 wurde nicht gefunden."
    echo "Bitte installiere Python 3 (z. B. von https://www.python.org/downloads/) und starte diese Datei danach erneut."
    read -p "Enter druecken zum Schliessen ..." dummy
    exit 1
fi

echo "========================================"
echo " SD Bewerbungsstudio wird gestartet ..."
echo " Adresse: http://localhost:$PORT/"
echo " Dieses Fenster bitte offen lassen, solange du die App benutzt."
echo " Zum Beenden: Fenster schliessen oder Strg+C druecken."
echo "========================================"

( sleep 1 && open "http://localhost:$PORT/index.html" ) &

"$PYTHON_BIN" -m http.server "$PORT"
