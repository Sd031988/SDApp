#!/bin/bash
cd "$(dirname "$0")/app" || exit 1
PORT=8791

PYTHON_BIN=""
if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="python3"
elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python"
fi

if [ -z "$PYTHON_BIN" ]; then
    echo "Python 3 wurde nicht gefunden."
    echo "Bitte installiere Python 3 ueber die Paketverwaltung deiner Distribution (z. B. 'sudo apt install python3') und starte dieses Skript danach erneut."
    read -p "Enter druecken zum Schliessen ..." dummy
    exit 1
fi

echo "========================================"
echo " SD Bewerbungsstudio wird gestartet ..."
echo " Adresse: http://localhost:$PORT/"
echo " Dieses Fenster bitte offen lassen, solange du die App benutzt."
echo " Zum Beenden: Fenster schliessen oder Strg+C druecken."
echo "========================================"

(
  sleep 1
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:$PORT/index.html" >/dev/null 2>&1
  elif command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser "http://localhost:$PORT/index.html" >/dev/null 2>&1
  else
    echo "Bitte oeffne http://localhost:$PORT/index.html manuell in deinem Browser."
  fi
) &

"$PYTHON_BIN" -m http.server "$PORT"
